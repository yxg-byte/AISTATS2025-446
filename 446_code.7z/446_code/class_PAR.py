#This file contains algorithms used for the PAR model, corresponding to section 5.3 in the paper.
import numpy as np
from scipy.special import factorial

class PAR:
    def __init__(self,mu0,y):
        self.mu0=mu0
        self.y=y
        self.T=len(y)
    
    @staticmethod
    def logsumexp(log_w):
        val=np.log(np.mean(np.exp(log_w)))
        return val
        
    @staticmethod
    def normalize_log_w(log_w):
        log_w -= np.max(log_w)
        w = np.exp(log_w)
        w /= np.sum(w)
        return w
    
    @staticmethod
    def fisher(vec,log_w):
        log_w -= np.max(log_w)
        w = np.exp(log_w)
        val=np.sum(vec*w)/np.sum(w)
        return val

    @staticmethod
    def ess(log_w):
        w = PAR.normalize_log_w(log_w)
        return 1 / np.sum(w ** 2)

    @staticmethod
    def resample(log_w):
        N = len(log_w)
        index = np.random.choice(np.arange(N), size=N, p=PAR.normalize_log_w(log_w))
        return index
    @staticmethod
    def getisw(X1_sq,X1__1,X_1sq,theta):
        val=X1_sq-2*theta*X1__1+X_1sq*theta**2
        return val
    @staticmethod
    def Zt(theta,t):
        return(theta[0]+theta[1]*t/1000+theta[2]*np.cos(t*np.pi/6)+theta[3]*np.sin(t*np.pi/6)+theta[4]*np.cos(t*np.pi/3)+theta[5]*np.sin(t*np.pi/3))
    @staticmethod
    def logpoid(Yt,X,theta,t):
        val=Yt*(X+PAR.Zt(theta,t))-np.log(factorial(Yt))-np.exp(X+PAR.Zt(theta,t))
        return(val)
    
    def NGA(self,theta_ini,c1,c2,c3,A,alpha,gamma,I,N):
        thetalist=theta_ini
        mu0=self.mu0
        #sigma0=self.sigma0
        y=self.y
        T=self.T
        for nI in range(I):
            cn=c2/((nI+1)**gamma)
            an=c1/((nI+A+1)**alpha)
            delta=2*np.random.binomial(1,[.5]*8)-1
            theta_f=thetalist[-1]+cn*delta
            theta_b=thetalist[-1]-cn*delta
            sigma0_f=theta_f[7]*(1-theta_f[6]**2)**-0.5
            X_f=np.random.normal(mu0,sigma0_f,N)  #q(x0|y0=mu(x0))
            #log_w_f=poisson.pmf(Y[0],np.exp(X_f+Zt(theta_f[:6],0)))
            log_w_f=PAR.logpoid(y[0],X_f,theta_f[:6],1)
            #print(log_w_f)
            ind_f=PAR.resample(log_w_f)
            X_f=[X_f[ind_f]]
            l_f=PAR.logsumexp(log_w_f)
            sigma0_b=theta_b[7]*(1-theta_b[6]**2)**-0.5
            X_b=np.random.normal(mu0,sigma0_b,N)  #q(x0|y0=mu(x0))
            #log_w_b=poisson.pmf(Y[0],np.exp(X_b+Zt(theta_b[:6],0)))
            log_w_b=PAR.logpoid(y[0],X_b,theta_b[:6],1)
            ind_b=PAR.resample(log_w_b)
            X_b=[X_b[ind_b]]
            l_b=PAR.logsumexp(log_w_b)

            
            for t in np.arange(1,T):
                X_f_tem=np.random.normal(theta_f[6]*X_f[-1],theta_f[7],N) 
                #w_f_tem=poisson.pmf(Y[t+1],np.exp(X_f_tem+Zt(theta_f[:6],t+2)))
                log_w_f=PAR.logpoid(y[t],X_f_tem,theta_f[:6],t+1)
                #alt=np.log(poisson.pmf(Y[t],np.exp(X_f_tem+Zt(theta_f[:6],t+1))))
                #print(sum((log_w_f-alt)**2))
                X_f=np.append(X_f,[X_f_tem],axis=0)
                ind_f=PAR.resample(log_w_f)
                X_f=X_f[:,ind_f]
                l_f+=PAR.logsumexp(log_w_f)
                X_b_tem=np.random.normal(theta_b[6]*X_b[-1],theta_b[7],N) 
                #w_b_tem=poisson.pmf(Y[t+1],np.exp(X_b_tem+Zt(theta_b[:6],t+2)))
                log_w_b=PAR.logpoid(y[t],X_b_tem,theta_b[:6],t+1)
                X_b=np.append(X_b,[X_b_tem],axis=0)
                ind_b=PAR.resample(log_w_b)
                X_b=X_b[:,ind_b]
                l_b+=PAR.logsumexp(log_w_b)
                                
            grad=(l_f-l_b)/2/cn/delta
            grad[1]*=c3#scaling as nemeth
            thetalist=np.append(thetalist,[thetalist[-1]+an*grad],axis=0)
        self.thetalist=thetalist
        
        
    def FGA(self,theta_ini,c1,c3,A,alpha,I,N):
        thetalist=theta_ini
        mu0=self.mu0
        #sigma0=self.sigma0
        y=self.y
        T=self.T
        tt=np.arange(1,T+1)
        for nI in range(I):
            #print(nI)
            an=c1/((nI+A+1)**alpha)
            sigma0=thetalist[-1][7]*(1-thetalist[-1][6]**2)**-0.5
            X=np.random.normal(mu0,sigma0,N)  #q(x0|y0=mu(x0))
            #log_w_f=poisson.pmf(Y[0],np.exp(X_f+Zt(theta_f[:6],0)))
            log_w=PAR.logpoid(y[0],X,thetalist[-1][:6],1)
            #print(log_w_f)
            ind=PAR.resample(log_w)
            X=[X[ind]]

            for t in np.arange(1,T):
                X_tem=np.random.normal(thetalist[-1][6]*X[-1],thetalist[-1][7],N) 
                #w_f_tem=poisson.pmf(Y[t+1],np.exp(X_f_tem+Zt(theta_f[:6],t+2)))
                #print(np.max(X_tem+Zt(thetalist[-1][:6],t+1)))
                log_w=PAR.logpoid(y[t],X_tem,thetalist[-1][:6],t+1)
                #print(np.max(np.exp(X_tem+Zt(thetalist[-1][:6],t+1))),t)
                #alt=np.log(poisson.pmf(Y[t],np.exp(X_f_tem+Zt(theta_f[:6],t+1))))
                #print(sum((log_w_f-alt)**2))
                X=np.append(X,[X_tem],axis=0)
                ind=PAR.resample(log_w)
                X=X[:,ind]
            log_w=np.zeros(N)
            vec7= thetalist[-1][6] *X[0]**2
            vec8=(1-thetalist[-1][6]**2)*X[0]**2
            grad_phi=PAR.fisher(np.sum(X[:-1]*(X[1:]-thetalist[-1][6]*X[:-1]),axis=0),log_w)/thetalist[-1][7]**2 -thetalist[-1][6] / (1 - thetalist[-1][6]**2)+PAR.fisher(vec7,log_w)/thetalist[-1][7]**2
            grad_sx=-T/thetalist[-1][7]+PAR.fisher(np.sum((X[1:]-thetalist[-1][6]*X[:-1])**2,axis=0),log_w)/thetalist[-1][7]**3+PAR.fisher(vec8,log_w)/thetalist[-1][7]**3
            mat_e=np.exp(X+PAR.Zt(thetalist[-1][:6],tt).reshape(T,1)*np.ones(N))
            grad_m1=np.sum(y)-PAR.fisher(np.sum(mat_e,axis=0),log_w)
            grad_m2=np.sum(y*tt)/1000-PAR.fisher(np.sum(mat_e*(tt.reshape(T,1)*np.ones(N)),axis=0),log_w)/1000
            grad_m3=np.sum(y*np.cos(np.pi*tt/6))-PAR.fisher(np.sum(mat_e*(np.cos(np.pi*tt/6).reshape(T,1)*np.ones(N)),axis=0),log_w)
            grad_m4=np.sum(y*np.sin(np.pi*tt/6))-PAR.fisher(np.sum(mat_e*(np.sin(np.pi*tt/6).reshape(T,1)*np.ones(N)),axis=0),log_w)
            grad_m5=np.sum(y*np.cos(np.pi*tt/3))-PAR.fisher(np.sum(mat_e*(np.cos(np.pi*tt/3).reshape(T,1)*np.ones(N)),axis=0),log_w)
            grad_m6=np.sum(y*np.sin(np.pi*tt/3))-PAR.fisher(np.sum(mat_e*(np.sin(np.pi*tt/3).reshape(T,1)*np.ones(N)),axis=0),log_w)      
            grad=np.array([grad_m1,grad_m2,grad_m3,grad_m4,grad_m5,grad_m6,grad_phi,grad_sx])
            grad[1]*=c3

            #grad_phi,grad_sy=0,0
            thetalist=np.append(thetalist,[thetalist[-1]+an*grad],axis=0)
        self.thetalist=thetalist

        
    
        
    def AGA(self,theta_ini,c1,c3,A,alpha,I,N,r,inner_K):   
        thetalist=theta_ini
        mu0=self.mu0
        y=self.y
        T=self.T
        tt=np.arange(1,T+1)
        n=0
        for nI in range(I):
            k=0
            ess=2
            thetalast=thetalist[-1]
            sigma0=thetalist[-1][7]*(1-thetalist[-1][6]**2)**-0.5
            #print(philist[-1],sxlist[-1],sylist[-1])
            X=np.random.normal(mu0,sigma0,N)  #q(x0|y0=mu(x0))
            #log_w_f=poisson.pmf(Y[0],np.exp(X_f+Zt(theta_f[:6],0)))
            log_w=PAR.logpoid(y[0],X,thetalast[:6],1)
            #print(log_w_f)
            ind=PAR.resample(log_w)
            X=[X[ind]]

            for t in np.arange(1,T):
                X_tem=np.random.normal(thetalast[6]*X[-1],thetalast[7],N) 
                #w_f_tem=poisson.pmf(Y[t+1],np.exp(X_f_tem+Zt(theta_f[:6],t+2)))
                #print(np.max(X_tem+Zt(thetalist[-1][:6],t+1)))
                log_w=PAR.logpoid(y[t],X_tem,thetalast[:6],t+1)
                #print(np.max(np.exp(X_tem+Zt(thetalist[-1][:6],t+1))),t)
                #alt=np.log(poisson.pmf(Y[t],np.exp(X_f_tem+Zt(theta_f[:6],t+1))))
                #print(sum((log_w_f-alt)**2))
                X=np.append(X,[X_tem],axis=0)
                ind=PAR.resample(log_w)
                X=X[:,ind]
            log_w=np.zeros(N)
            islogw=np.zeros(N)
            logx_last=-np.sum((X[1:]-thetalast[6]*X[:-1])**2,axis=0)/2/thetalast[7]**2     -X[0]**2*(1-thetalast[6]**2 )/2/thetalast[7]**2       
            logy_last=np.sum(PAR.logpoid(y.reshape(T,1)*np.ones(N),X,thetalast,tt.reshape(T,1)*np.ones(N)),axis=0) 

            
            while ((ess > r)&(k<inner_K)):
                n+=1
                k+=1
                an=c1/((n+A)**alpha)
    

                
                grad_phi=PAR.fisher(np.sum(X[:-1]*(X[1:]-thetalist[-1][6]*X[:-1]),axis=0),islogw)/thetalist[-1][7]**2-thetalist[-1][6] / (1 - thetalist[-1][6]**2)+PAR.fisher(thetalist[-1][6] *X[0]**2,log_w)/thetalist[-1][7]**2
                grad_sx=-T/thetalist[-1][7]+PAR.fisher(np.sum((X[1:]-thetalist[-1][6]*X[:-1])**2,axis=0),islogw)/thetalist[-1][7]**3 +PAR.fisher((1-thetalist[-1][6]**2)*X[0]**2,log_w)/thetalist[-1][7]**3
                mat_e=np.exp(X+PAR.Zt(thetalist[-1][:6],tt).reshape(T,1)*np.ones(N))

                vec1=np.sum(mat_e,axis=0)
                vec2=np.sum(mat_e*(tt.reshape(T,1)*np.ones(N)),axis=0)
                vec3=np.sum(mat_e*(np.cos(np.pi*tt/6).reshape(T,1)*np.ones(N)),axis=0)
                vec4=np.sum(mat_e*(np.sin(np.pi*tt/6).reshape(T,1)*np.ones(N)),axis=0)
                vec5=np.sum(mat_e*(np.cos(np.pi*tt/3).reshape(T,1)*np.ones(N)),axis=0)
                vec6=np.sum(mat_e*(np.sin(np.pi*tt/3).reshape(T,1)*np.ones(N)),axis=0)
                
                grad_m1=np.sum(y)-PAR.fisher(vec1,islogw)
                grad_m2=np.sum(y*tt)/1000-PAR.fisher(vec2,islogw)/1000
                grad_m3=np.sum(y*np.cos(np.pi*tt/6))-PAR.fisher(vec3,islogw)
                grad_m4=np.sum(y*np.sin(np.pi*tt/6))-PAR.fisher(vec4,islogw)
                grad_m5=np.sum(y*np.cos(np.pi*tt/3))-PAR.fisher(vec5,islogw)
                grad_m6=np.sum(y*np.sin(np.pi*tt/3))-PAR.fisher(vec6,islogw)      
                grad=np.array([grad_m1,grad_m2,grad_m3,grad_m4,grad_m5,grad_m6,grad_phi,grad_sx])
                grad[1]*=c3
                ess=PAR.ess(islogw)/N
                #print(nI,ess)
                thetalist=np.append(thetalist,[thetalist[-1]+an*grad],axis=0)
                logx=-np.sum((X[1:]-thetalist[-1][6]*X[:-1])**2,axis=0)/2/thetalist[-1][7]**2  -X[0]**2*(1-thetalist[-1][6]**2 )/2/thetalist[-1][7]**2 
                logy=np.sum(PAR.logpoid(y.reshape(T,1)*np.ones(N),X,thetalist[-1],tt.reshape(T,1)*np.ones(N)),axis=0)
                islogw=logx+logy-logx_last-logy_last
        self.thetalist=thetalist
        

    def onGA1(self,theta_ini,c1,c3,A,alpha,N,r1,r2,REP):
        thetalist=theta_ini
        mu0=self.mu0
        y=self.y
        T=self.T       
        k1=0
        renew_t=[]
        for rep in range(REP):
            thetalast=thetalist[-1]
            sigma0=thetalist[-1][7]*(1-thetalist[-1][6]**2)**-0.5
            X=np.random.normal(mu0,sigma0,N)  #q(x0|y0=mu(x0))
            #log_w_f=poisson.pmf(Y[0],np.exp(X_f+Zt(theta_f[:6],0)))
            log_w=PAR.logpoid(y[0],X,thetalist[-1][:6],1)
            #print(log_w_f)
            ind=PAR.resample(log_w)
            X=np.array([X[ind]])
            log_w=np.zeros(N)
            for t in np.arange(1,T):
                tt=np.arange(1,t+1)
                #propagation
                an=T*c1/(t+A+rep*T)**alpha#a_t=(T+1)*c1/((rep*T+t+A+1)**alpha)

                #w_f_tem=poisson.pmf(Y[t+1],np.exp(X_f_tem+Zt(theta_f[:6],t+2)))
                #print(np.max(X_tem+Zt(thetalist[-1][:6],t+1)))


                '''
                next:calculate gradient(or not needed ?) to give a more efficient form
                also check the code()thetalast and thetalist[-1]
                '''
                mat_e=np.exp(X+PAR.Zt(thetalist[-1][:6],tt).reshape(t,1)*np.ones(N))

                vec1=np.sum(mat_e,axis=0)
                vec2=np.sum(mat_e*(tt.reshape(t,1)*np.ones(N)),axis=0)
                vec3=np.sum(mat_e*(np.cos(np.pi*tt/6).reshape(t,1)*np.ones(N)),axis=0)
                vec4=np.sum(mat_e*(np.sin(np.pi*tt/6).reshape(t,1)*np.ones(N)),axis=0)
                vec5=np.sum(mat_e*(np.cos(np.pi*tt/3).reshape(t,1)*np.ones(N)),axis=0)
                vec6=np.sum(mat_e*(np.sin(np.pi*tt/3).reshape(t,1)*np.ones(N)),axis=0)
                vec7=np.sum(X[:-1]*(X[1:]-thetalist[-1][6]*X[:-1]),axis=0)+thetalist[-1][6] *X[0]**2
                vec8=np.sum((X[1:]-thetalist[-1][6]*X[:-1])**2,axis=0)+(1-thetalist[-1][6]**2)*X[0]**2



                grad_m1_o=-PAR.fisher(vec1,log_w)
                grad_m2_o=-PAR.fisher(vec2,log_w)/1000
                grad_m3_o=-PAR.fisher(vec3,log_w)
                grad_m4_o=-PAR.fisher(vec4,log_w)
                grad_m5_o=-PAR.fisher(vec5,log_w)
                grad_m6_o=-PAR.fisher(vec6,log_w)   
                grad_phi_o=PAR.fisher(vec7,log_w)/thetalist[-1][7]**2
                grad_sx_o=PAR.fisher(vec8,log_w)/thetalist[-1][7]**3

                X_tem=np.random.normal(thetalist[-1][6]*X[-1],thetalist[-1][7],N) 

                log_w+=PAR.logpoid(y[t],X_tem,thetalist[-1][:6],t+1)

                vec1+=np.exp(X_tem+PAR.Zt(thetalist[-1][:6],t+1))
                vec2+=np.exp(X_tem+PAR.Zt(thetalist[-1][:6],t+1))*(t+1)   
                vec3+=np.exp(X_tem+PAR.Zt(thetalist[-1][:6],t+1))*np.cos(np.pi*(t+1)/6)
                vec4+=np.exp(X_tem+PAR.Zt(thetalist[-1][:6],t+1))*np.sin(np.pi*(t+1)/6)
                vec5+=np.exp(X_tem+PAR.Zt(thetalist[-1][:6],t+1))*np.cos(np.pi*(t+1)/3)
                vec6+=np.exp(X_tem+PAR.Zt(thetalist[-1][:6],t+1))*np.sin(np.pi*(t+1)/3)
                vec7+=X[-1]*(X_tem-thetalist[-1][6]*X[-1]) 
                vec8+=(X_tem-thetalist[-1][6]*X[-1])**2 



                X=np.append(X,[X_tem],axis=0)
                tt=np.arange(1,t+2)

                grad_m1_n=y[t]-PAR.fisher(vec1,log_w)
                grad_m2_n=y[t]*(t+1)/1000-PAR.fisher(vec2,log_w)/1000
                grad_m3_n=(y[t]*np.cos(np.pi*(t+1)/6))-PAR.fisher(vec3,log_w)
                grad_m4_n=(y[t]*np.sin(np.pi*(t+1)/6))-PAR.fisher(vec4,log_w)
                grad_m5_n=(y[t]*np.cos(np.pi*(t+1)/3))-PAR.fisher(vec5,log_w)
                grad_m6_n=(y[t]*np.sin(np.pi*(t+1)/3))-PAR.fisher(vec6,log_w)
                grad_phi_n=PAR.fisher(vec7,log_w)/thetalist[-1][7]**2
                grad_sx_n=-1/thetalist[-1][7]+PAR.fisher(vec8,log_w)/thetalist[-1][7]**3


                grad_phi=grad_phi_n-grad_phi_o
                grad_sx=grad_sx_n-grad_sx_o
                grad_m1=grad_m1_n-grad_m1_o
                grad_m2=grad_m2_n-grad_m2_o
                grad_m3=grad_m3_n-grad_m3_o
                grad_m4=grad_m4_n-grad_m4_o
                grad_m5=grad_m5_n-grad_m5_o
                grad_m6=grad_m6_n-grad_m6_o
                grad=np.array([grad_m1,grad_m2,grad_m3,grad_m4,grad_m5,grad_m6,grad_phi,grad_sx])
                grad[1]*=c3
                thetalist=np.append(thetalist,[thetalist[-1]+an*grad],axis=0)


                logx=-np.sum((X[1:]-thetalist[-1][6]*X[:-1])**2,axis=0)/2/thetalist[-1][7]**2 -X[0]**2*(1-thetalist[-1][6]**2 )/2/thetalist[-1][7]**2
                logy=np.sum(PAR.logpoid(y[:t+1].reshape(t+1,1)*np.ones(N),X,thetalist[-1],tt.reshape(t+1,1)*np.ones(N)),axis=0)
                logx_last=-np.sum((X[1:]-thetalast[6]*X[:-1])**2,axis=0)/2/thetalast[7]**2 -X[0]**2*(1-thetalast[6]**2 )/2/thetalast[7]**2
                logy_last=np.sum(PAR.logpoid(y[:t+1].reshape(t+1,1)*np.ones(N),X,thetalast,tt.reshape(t+1,1)*np.ones(N)),axis=0)

                islogw=logx+logy-logx_last-logy_last

                logx_o=-np.sum((X[1:]-thetalist[-2][6]*X[:-1])**2,axis=0)/2/thetalist[-2][7]**2-X[0]**2*(1-thetalist[-2][6]**2 )/2/thetalist[-2][7]**2
                logy_o=np.sum(PAR.logpoid(y[:t+1].reshape(t+1,1)*np.ones(N),X,thetalist[-2],tt.reshape(t+1,1)*np.ones(N)),axis=0)

                rtgt_logw=logx+logy-logx_o-logy_o
                log_w+=rtgt_logw

                ess_a=PAR.ess(islogw)/N
                ess_w=PAR.ess(log_w)/N


                #print(ess_a,ess_w)          
                if(ess_a<r1):
                    #print(t)
                    k1+=1
                    renew_t.append(t)
                    thetalast=thetalist[-1]
                    sigma0=thetalist[-1][7]*(1-thetalist[-1][6]**2)**-0.5
                    X=np.random.normal(mu0,sigma0,N)  #q(x0|y0=mu(x0))
                    #log_w_f=poisson.pmf(Y[0],np.exp(X_f+Zt(theta_f[:6],0)))
                    log_w=PAR.logpoid(y[0],X,thetalist[-1][:6],1)
                    #print(log_w_f)
                    ind=PAR.resample(log_w)
                    X=[X[ind]]
                    log_w=np.zeros(N)
                    for t1 in np.arange(1,t+1):
                        X_tem=np.random.normal(thetalist[-1][6]*X[-1],thetalist[-1][7],N) 
                        X=np.append(X,[X_tem],axis=0)
                        log_w=PAR.logpoid(y[t1],X_tem,thetalist[-1][:6],t1+1)
                        ind=PAR.resample(log_w)
                        X=X[:,ind]
                    log_w=np.zeros(N)


                elif(ess_w<r2):
                    ind=PAR.resample(log_w)
                    X=X[:,ind]
                    log_w=np.zeros(N)
                    #add other summary stats if needed
                    
        self.renew_t=renew_t
        self.k1=k1    
        self.thetalist=thetalist
