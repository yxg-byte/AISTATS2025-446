#This file contains algorithms used for the AR(1) model, corresponding to section 5.1 in the paper.
import numpy as np
class AR1:
    def __init__(self,y):
        self.y=y
        self.T=len(y)
    
    @staticmethod
    def logsumexp(log_w):
        val=np.log(np.sum(np.exp(log_w)))
        return val
        
    @staticmethod
    def normalize_log_w(log_w):
        log_w -= np.max(log_w)
        w = np.exp(log_w)
        w /= np.sum(w)
        return w
    
    @staticmethod
    def fisher(vec,log_w):
        log_w -= np.max(log_w)
        w = np.exp(log_w)
        val=np.sum(vec*w)/np.sum(w)
        return val

    @staticmethod
    def ess(log_w):
        w = AR1.normalize_log_w(log_w)
        return 1 / np.sum(w ** 2)

    @staticmethod
    def resample(log_w):
        N = len(log_w)
        index = np.random.choice(np.arange(N), size=N, p=AR1.normalize_log_w(log_w))
        return index
    @staticmethod
    def getisw(X02,X1_sq,X1__1,X_1sq,phi,sigmax,sigmay,phi_l,sigmax_l,sigmay_l,vec2_s,vec3):       
        islogw0=X02 *(-(1-phi**2)/2/sigmax**2+(1-phi_l**2)/2/sigmax_l**2)
        islogwx=-vec2_s/2/sigmax**2+(X1_sq-2*phi_l*X1__1+phi_l**2*X_1sq)/2/sigmax_l**2        
        islogwy=(-1/2/sigmay**2+1/2/sigmay_l**2)*vec3 
        val=islogw0+islogwx+islogwy        
        
        return val
    #bt proposal
    def NGA(self,ini,c1,c2,A,alpha,gamma,I,N):
        thetalist=np.array([ini])#[]?
        T=self.T
        y=self.y
        for nI in range(I):
            an=c1/((nI+A)**alpha)
            cn=c2/((nI+1)**gamma)
            delta=2*np.random.binomial(1,[.5]*3)-1
            phi_f,sigmax_f,sigmay_f=thetalist[-1]+delta*cn
            sigma0_f=(1-phi_f**2)**-0.5*sigmax_f           
            X_f=np.random.normal(0,sigma0_f,N)  #q(x0|y0=mu(x0))
            log_w_f=-np.log(sigmay_f)-(y[0]-X_f)**2/2/sigmay_f**2
            ind_f=AR1.resample(log_w_f)
            X_f=X_f[ind_f]
            phi_b,sigmax_b,sigmay_b=thetalist[-1]-delta*cn
            sigma0_b=(1-phi_b**2)**-0.5*sigmax_b           
            X_b=np.random.normal(0,sigma0_b,N)  #q(x0|y0=mu(x0))
            log_w_b=-np.log(sigmay_b)-(y[0]-X_b)**2/2/sigmay_b**2
            ind_b=AR1.resample(log_w_b)
            X_b=X_b[ind_b]
            l_f=AR1.logsumexp(log_w_f)
            l_b=AR1.logsumexp(log_w_b)
            for t in np.arange(1,T):
                X_f_tem=np.random.normal(phi_f*X_f,sigmax_f,N) 
                log_w_f=-np.log(sigmay_f)-(y[t]-X_f_tem)**2/2/sigmay_f**2
                #X_f=np.append(X_f,[X_f_tem],axis=0)
                ind_f=AR1.resample(log_w_f)
                X_f=X_f_tem[ind_f]  
                l_f+=AR1.logsumexp(log_w_f)
                X_b_tem=np.random.normal(phi_b*X_b,sigmax_b,N) 
                log_w_b=-np.log(sigmay_b)-(y[t]-X_b_tem)**2/2/sigmay_b**2
                #X_b=np.append(X_b,[X_b_tem],axis=0)
                ind_b=AR1.resample(log_w_b)
                X_b=X_b_tem[ind_b] 
                l_b+=AR1.logsumexp(log_w_b)
                
            grad=(l_f-l_b)/2/cn/delta
            thetalist=np.append(thetalist,[thetalist[-1]+an*grad],axis=0)
        self.thetalist = thetalist
    #opt proposal
    def NGA1(self,ini,c1,c2,A,alpha,gamma,I,N):
        thetalist=np.array([ini])#[]?
        T=self.T
        y=self.y
        for nI in range(I):
            an=c1/((nI+A)**alpha)
            cn=c2/((nI+1)**gamma)
            delta=2*np.random.binomial(1,[.5]*3)-1
            phi_f,sigmax_f,sigmay_f=thetalist[-1]+delta*cn
            sigma0_f=(1-phi_f**2)**-0.5*sigmax_f 
            v_f_tot=sigma0_f**2+sigmay_f**2
            v_f_con=1/(sigma0_f**-2+sigmay_f**-2)
            mu_f=y[0]*sigma0_f**2/v_f_tot
            X_f=np.random.normal(mu_f,v_f_con**.5,N)  #q(x0|y0=mu(x0))
            phi_b,sigmax_b,sigmay_b=thetalist[-1]-delta*cn
            sigma0_b=(1-phi_b**2)**-0.5*sigmax_b 
            v_b_tot=sigma0_b**2+sigmay_b**2
            v_b_con=1/(sigma0_b**-2+sigmay_b**-2)
            mu_b=y[0]*sigma0_b**2/v_b_tot
            X_b=np.random.normal(mu_b,v_b_con**.5,N)  #q(x0|y0=mu(x0))
            0
            l_f=0
            l_b=0
            for t in np.arange(1,T):
                v_f_con=1/(sigmax_f**-2+sigmay_f**-2)
                v_f_tot=sigmax_f**2+sigmay_f**2
                mu_f=phi_f*X_f*sigmay_f**2/v_f_tot+y[t]*sigmax_f**2/v_f_tot
                diff_f=y[t]-phi_f*X_f
                X_f_tem=np.random.normal(mu_f,v_f_con**.5,N) 
                log_w_f=-np.log(v_f_tot)/2-diff_f**2/2/v_f_tot
                #X_f=np.append(X_f,[X_f_tem],axis=0)
                ind_f=AR1.resample(log_w_f)
                X_f=X_f_tem[ind_f]  
                l_f+=AR1.logsumexp(log_w_f)
                v_b_con=1/(sigmax_b**-2+sigmay_b**-2)
                v_b_tot=sigmax_b**2+sigmay_b**2
                mu_b=phi_b*X_b*sigmay_b**2/v_b_tot+y[t]*sigmax_b**2/v_b_tot
                diff_b=y[t]-phi_b*X_b
                X_b_tem=np.random.normal(mu_b,v_b_con**.5,N) 
                log_w_b=-np.log(v_b_tot)/2-diff_b**2/2/v_b_tot
                #X_b=np.append(X_b,[X_b_tem],axis=0)
                ind_b=AR1.resample(log_w_b)
                X_b=X_b_tem[ind_b]  
                l_b+=AR1.logsumexp(log_w_b)

                
            grad=(l_f-l_b)/2/cn/delta
            thetalist=np.append(thetalist,[thetalist[-1]+an*grad],axis=0)
        self.thetalist = thetalist
        
        
    #bt proposal    
    def FGA(self,ini,c1,A,alpha,I,N):   
        thetalist=np.array([ini])#[]?
        T=self.T
        y=self.y
        for nI in range(I):
            phi,sigmax,sigmay=thetalist[-1]
            sigma0=(1-phi**2)**-0.5*sigmax
            an=c1/((nI+A)**alpha)
            X=np.random.normal(0,sigma0,N)  #q(x0|y0=mu(x0))
            log_w=-(y[0]-X)**2/2/sigmay**2
            ind=AR1.resample(log_w)
            X=X[ind]
            v_phi= phi *X**2
            v_sx=(1-phi**2)*X**2
            v_sy=(y[0]-X)**2
            for t in np.arange(1,T):
                X_tem=np.random.normal(phi*X,sigmax,N) 
                log_w=-(y[t]-X_tem)**2/2/sigmay**2
                #X=np.append(X,[X_tem],axis=0)
                v_phi+=X*(X_tem-phi*X)
                v_sx+=(X_tem-phi*X)**2
                v_sy+=(y[t]-X_tem)**2
                
                
                ind=AR1.resample(log_w)
                X=X_tem[ind]
                v_phi=v_phi[ind]
                v_sx=v_sx[ind]
                v_sy=v_sy[ind]
            #grad_phi=np.sum(X[:-1]*(X[1:]-phi*X[:-1]))/sigmax**2/N -phi / (1 - phi**2) + phi * np.mean(X[0]**2) / sigmax**2
            #grad_sx=np.sum((X[1:]-phi*X[:-1])**2)/sigmax**3/N-T/sigmax +(1-phi**2)*np.mean(X[0]**2)/sigmax**3
            #grad_sy=np.sum((y[:,None]-X)**2)/sigmay**3/N-(T)/sigmay
            
            grad_phi=np.mean(v_phi)/sigmax**2 -phi / (1 - phi**2)
            grad_sx=np.mean(v_sx)/sigmax**3-T/sigmax
            grad_sy=np.mean(v_sy)/sigmay**3-T/sigmay
            
            grad=np.array([grad_phi,grad_sx,grad_sy])
            #print(grad)
            thetalist=np.append(thetalist,[thetalist[-1]+an*grad],axis=0)
        self.thetalist = thetalist
        
    #opt proposal
 
    def FGA1(self,ini,c1,A,alpha,I,N):   
        thetalist=np.array([ini])#[]?
        T=self.T
        y=self.y
        for nI in range(I):
            phi,sigmax,sigmay=thetalist[-1]
            sigma0=(1-phi**2)**-0.5*sigmax
            an=c1/((nI+A)**alpha)
            v_tot=sigma0**2+sigmay**2
            v_con=1/(sigma0**-2+sigmay**-2)
            mu=y[0]*sigma0**2/v_tot
            X=np.random.normal(mu,v_con**.5,N)
            v_phi= phi *X**2
            v_sx=(1-phi**2)*X**2
            v_sy=(y[0]-X)**2
            for t in np.arange(1,T):
                v_con=1/(sigmax**-2+sigmay**-2)
                v_tot=sigmax**2+sigmay**2
                mu=phi*X*sigmay**2/v_tot+y[t]*sigmax**2/v_tot
                diff=y[t]-phi*X
                X_tem=np.random.normal(mu,v_con**.5,N) 
                log_w=-diff**2/2/v_tot
                #X=np.append(X,[X_tem],axis=0)
                v_phi+=X*(X_tem-phi*X)
                v_sx+=(X_tem-phi*X)**2
                v_sy+=(y[t]-X_tem)**2
                
                
                ind=AR1.resample(log_w)
                X=X_tem[ind]
                v_phi=v_phi[ind]
                v_sx=v_sx[ind]
                v_sy=v_sy[ind]
            #grad_phi=np.sum(X[:-1]*(X[1:]-phi*X[:-1]))/sigmax**2/N -phi / (1 - phi**2) + phi * np.mean(X[0]**2) / sigmax**2
            #grad_sx=np.sum((X[1:]-phi*X[:-1])**2)/sigmax**3/N-T/sigmax +(1-phi**2)*np.mean(X[0]**2)/sigmax**3
            #grad_sy=np.sum((y[:,None]-X)**2)/sigmay**3/N-(T)/sigmay
            
            grad_phi=np.mean(v_phi)/sigmax**2 -phi / (1 - phi**2)
            grad_sx=np.mean(v_sx)/sigmax**3-T/sigmax
            grad_sy=np.mean(v_sy)/sigmay**3-T/sigmay
            
            grad=np.array([grad_phi,grad_sx,grad_sy])
            #print(grad)
            thetalist=np.append(thetalist,[thetalist[-1]+an*grad],axis=0)
        self.thetalist = thetalist
      

        #AGA reduced cost,bt
    def AGA(self,ini,c1,A,alpha,I,N,r,inner_K):   
        thetalist=np.array([ini])
        T=self.T
        y=self.y
        n=0
        for nI in range(I):
            k=0
            ess=2
            
            phi_l,sigmax_l,sigmay_l=thetalist[-1]
            sigma0_l=(1-phi_l**2)**-0.5*sigmax_l
            X=np.random.normal(0,sigma0_l,N)  #q(x0|y0=mu(x0))
            log_w=-(y[0]-X)**2/2/sigmay_l**2
            ind=AR1.resample(log_w)
            X=X[ind]
            X0=X
            X1_sq=np.zeros(N)
            X1__1=np.zeros(N)
            X_1sq=np.zeros(N)
            y_x=(y[0]-X)**2
            
            
            
            for t in np.arange(1,T):             
                X_tem=np.random.normal(phi_l*X,sigmax_l,N) 
                log_w=-(y[t]-X_tem)**2/2/sigmay_l**2
                #X=np.append(X,[X_tem],axis=0)
                
                X1_sq+=X_tem**2
                X1__1+=X*X_tem
                X_1sq+=X**2
                y_x+=(y[t]-X_tem)**2
                
                
                ind=AR1.resample(log_w)
                X=X_tem[ind]
                X1_sq=X1_sq[ind]
                X1__1=X1__1[ind]
                X_1sq=X_1sq[ind]
                y_x=y_x[ind]
                X0=X0[ind]
                
            islogw=np.zeros(N)
            while ((ess > r)&(k<inner_K)):
                n+=1
                k+=1
                an=c1/((n+A)**alpha)
                phi,sigmax,sigmay=thetalist[-1]
                
                
                
                #vec1=np.sum(X[:-1]*(X[1:]-phi*X[:-1]),axis=0)                
                #vec1=np.sum(X[:-1]*(X[1:]-phi*X[:-1]),axis=0)  + phi *(X[0]**2) / sigmax**2
            
                vec1=X1__1-phi*X_1sq  + phi *(X0**2) 
                grad_phi=AR1.fisher(vec1,islogw)/sigmax**2-phi / (1 - phi**2)
                
                #vec2=np.sum((X[1:]-phi*X[:-1])**2,axis=0) 
                #vec2=np.sum((X[1:]-phi*X[:-1])**2,axis=0) -1/sigmax+(1-phi**2)*(X[0]**2)/sigmax**3
                vec2_s=X1_sq-2*phi*X1__1+phi**2*X_1sq
                vec2=vec2_s/sigmax**3 -1/sigmax+(1-phi**2)*(X0**2)/sigmax**3
                grad_sx=AR1.fisher(vec2,islogw)-(T-1)/sigmax
                
                vec3=y_x
                grad_sy=AR1.fisher(vec3,islogw)/sigmay**3-T/sigmay
                grad=np.array([grad_phi,grad_sx,grad_sy])
                
                thetalist=np.append(thetalist,[thetalist[-1]+an*grad],axis=0)
                
                
                #islogwx=-np.sum((X[1:]-phi*X[:-1])**2,axis=0)/2/sigmax**2+np.sum((X[1:]-phi_l*X[:-1])**2,axis=0)/2/sigmax_l**2      
                #islogwy=(-1/2/sigmay**2+1/2/sigmay_l**2)*vec3
                #islogw=islogwx+islogwy
                islogw=AR1.getisw(X0**2,X1_sq,X1__1,X_1sq,phi,sigmax,sigmay,phi_l,sigmax_l,sigmay_l,vec2_s,vec3)
                ess=AR1.ess(islogw)/N
            print(k)
        self.thetalist = thetalist 
        
        
     #AGA reduced cost,opt
    def AGA1(self,ini,c1,A,alpha,I,N,r,inner_K):   
        thetalist=np.array([ini])
        T=self.T
        y=self.y
        n=0
        for nI in range(I):
            k=0
            ess=2
            
            phi_l,sigmax_l,sigmay_l=thetalist[-1]
            sigma0_l=(1-phi_l**2)**-0.5*sigmax_l
            v_tot=sigma0_l**2+sigmay_l**2
            v_con=1/(sigma0_l**-2+sigmay_l**-2)
            mu=y[0]*sigma0_l**2/v_tot
            X=np.random.normal(mu,v_con**.5,N)
            X0=X
            X1_sq=np.zeros(N)
            X1__1=np.zeros(N)
            X_1sq=np.zeros(N)
            y_x=(y[0]-X)**2
            
            
            
            for t in np.arange(1,T):             
                v_con=1/(sigmax_l**-2+sigmay_l**-2)
                v_tot=sigmax_l**2+sigmay_l**2
                mu=phi_l*X*sigmay_l**2/v_tot+y[t]*sigmax_l**2/v_tot
                diff=y[t]-phi_l*X
                X_tem=np.random.normal(mu,v_con**.5,N) 
                log_w=-diff**2/2/v_tot
                #X=np.append(X,[X_tem],axis=0)
                
                X1_sq+=X_tem**2
                X1__1+=X*X_tem
                X_1sq+=X**2
                y_x+=(y[t]-X_tem)**2
                
                
                ind=AR1.resample(log_w)
                X=X_tem[ind]
                X1_sq=X1_sq[ind]
                X1__1=X1__1[ind]
                X_1sq=X_1sq[ind]
                y_x=y_x[ind]
                X0=X0[ind]
                
            islogw=np.zeros(N)
            while ((ess > r)&(k<inner_K)):
                n+=1
                k+=1
                an=c1/((n+A)**alpha)
                phi,sigmax,sigmay=thetalist[-1]
                
                
                
                #vec1=np.sum(X[:-1]*(X[1:]-phi*X[:-1]),axis=0)                
                #vec1=np.sum(X[:-1]*(X[1:]-phi*X[:-1]),axis=0)  + phi *(X[0]**2) / sigmax**2
            
                vec1=X1__1-phi*X_1sq  + phi *(X0**2) 
                grad_phi=AR1.fisher(vec1,islogw)/sigmax**2-phi / (1 - phi**2)
                
                #vec2=np.sum((X[1:]-phi*X[:-1])**2,axis=0) 
                #vec2=np.sum((X[1:]-phi*X[:-1])**2,axis=0) -1/sigmax+(1-phi**2)*(X[0]**2)/sigmax**3
                vec2_s=X1_sq-2*phi*X1__1+phi**2*X_1sq
                vec2=vec2_s/sigmax**3 -1/sigmax+(1-phi**2)*(X0**2)/sigmax**3
                grad_sx=AR1.fisher(vec2,islogw)-(T-1)/sigmax
                
                vec3=y_x
                grad_sy=AR1.fisher(vec3,islogw)/sigmay**3-T/sigmay
                grad=np.array([grad_phi,grad_sx,grad_sy])
                
                thetalist=np.append(thetalist,[thetalist[-1]+an*grad],axis=0)
                
                
                #islogwx=-np.sum((X[1:]-phi*X[:-1])**2,axis=0)/2/sigmax**2+np.sum((X[1:]-phi_l*X[:-1])**2,axis=0)/2/sigmax_l**2      
                #islogwy=(-1/2/sigmay**2+1/2/sigmay_l**2)*vec3
                #islogw=islogwx+islogwy
                islogw=AR1.getisw(X0**2,X1_sq,X1__1,X_1sq,phi,sigmax,sigmay,phi_l,sigmax_l,sigmay_l,vec2_s,vec3)
                ess=AR1.ess(islogw)/N
            #print(k)    
        self.thetalist = thetalist
    
    
        
        
    
    def ON2(self,ini,I,N):   
        thetalist=np.array([ini])#[]?
        T=self.T
        y=self.y
        for nI in range(I):
            phi,sigma,tau=thetalist[-1]
            sigma0=(1-phi**2)**-0.5*sigma
            #an=c1/((nI+A)**alpha)
            X = np.random.normal(0, np.sqrt((sigma**2) / (1 - phi**2)), N)  # Initialise
            Alphas = np.zeros((3, N))  # dlogP(x_n,y_1:n)
            Sn = np.zeros((T, 3))  # dlogP(y_1:n)
            Betas = np.zeros((N, 3, 3))  # dlog2(p(x_1:T,y_1:T))
            Sigma = np.zeros((T, 3, 3))  # -dlog2(p(y_1:T))
            Alphas[0, :] = -phi / (1 - phi**2) + phi * (X / sigma)**2
            Alphas[1, :] = -1 / sigma + (1 - phi**2) * X**2 / sigma**3
            Betas[:, 0, 0] = (X / sigma)**2 - 1 / (1 - phi**2) - 2 * phi**2 / (1 - phi**2)**2
            Betas[:, 0, 1] = -2 * phi * X**2 / sigma**3
            Betas[:, 1, 0] = Betas[:, 0, 1]
            Betas[:, 1, 1] = 1 / (sigma**2) - 3 * X**2 * (1 - phi**2) / (sigma**4)
            Sn[0, :] = np.mean(Alphas, axis=1)
            Sigma[0, :, :] = -np.cov(Alphas,bias=True) - np.mean(Betas, axis=0)

            for t in range(1, T):

                w0 = -(y[t]- phi * X)**2/2/(sigma**2 + tau**2)
                weights = np.exp(w0 - np.max(w0))
                k = np.random.choice(range(N), size=N, replace=True, p=weights / np.sum(weights))  # Resample
                X1 = X
                omega2 = 1 / (1 / sigma**2 + 1 / tau**2)
                mu = omega2 * (y[t] / tau**2 + phi * X1[k] / sigma**2)
                X = np.random.normal(mu, np.sqrt(omega2))

                # Calculate w[t]f_theta(X[t]|X[t-1])
                xtemp = np.tile(X, (N, 1)).T
                x1temp = np.tile(phi * X1, (N, 1))#.T
                #print(xtemp,x1temp)
                wf = xtemp - x1temp
                wf = np.exp(-0.5 * wf**2 /sigma**2) / np.sqrt(2 * np.pi * sigma**2) #?
                sum_f = np.sum(wf, axis=1)

                # Estimate the joint score 
                Alphas_n = Alphas.copy()  # concern over updating alpha whilst running the recursions
                Alphas_n[0, :] = [np.sum(wf[i, :] * (Alphas[0, :] + (X1 / sigma**2) * (X[i] - phi * X1)))/sum_f[i] for i in range(N)]
                Alphas_n[1, :] = [np.sum(wf[i, :] * (Alphas[1, :] - 1/sigma + (X[i] - phi * X1)**2 / sigma**3))/sum_f[i] for i in range(N)]
                Alphas_n[2, :] = [np.sum(wf[i, :] * (Alphas[2, :] - 1/tau + (1/tau**3) * (y[t] - X[i])**2))/sum_f[i] for i in range(N)]

                # Estimate observed information of joint dist
                Betas_n = Betas.copy()
                Betas_n[:, 0, 0] = [np.sum(wf[i, :] / sum_f[i] * ((Alphas[0, :] + (X1 / sigma**2) * (X[i] - phi * X1))**2 + (Betas[:, 0, 0] - (X1 / sigma)**2))) - Alphas_n[0, i] * Alphas_n[0, i].T for i in range(N)]
                Betas_n[:, 0, 1] = [np.sum(wf[i, :] / sum_f[i] * ((Betas[:, 0, 1] - (2 * X1 / (sigma**3)) * (X[i] - phi * X1)) + (Alphas[0, :] + (X1 / sigma**2) * (X[i] - phi * X1)) * (Alphas[1, :] - 1/sigma + (X[i] - phi * X1)**2 / sigma**3))) - Alphas_n[0, i] * Alphas_n[1, i].T for i in range(N)]
                Betas_n[:, 1, 0] = Betas_n[:, 0, 1]
                Betas_n[:, 0, 2] = [np.sum(wf[i, :] / sum_f[i] * ((Alphas[0, :] + (X1 / sigma**2) * (X[i] - phi * X1)) * (Alphas[2, :] - 1/tau + (1/tau**3) * (y[t] - X[i])**2))) - Alphas_n[0, i] * Alphas_n[2, i].T for i in range(N)]
                Betas_n[:, 2, 0] = Betas_n[:, 0, 2]
                Betas_n[:, 1, 1] = [np.sum(wf[i, :] / sum_f[i] * ((Betas[:, 1, 1] + 1/sigma**2 - 3 * (X[i] - phi * X1)**2 / (sigma**4)) + (Alphas[1, :] - 1/sigma + (X[i] - phi * X1)**2 / sigma**3)**2)) - Alphas_n[1, i] * Alphas_n[1, i].T for i in range(N)]
                Betas_n[:, 1, 2] = [np.sum(wf[i, :] / sum_f[i] * ((Alphas[1, :] - 1/sigma + (X[i] - phi * X1)**2 / sigma**3) * (Alphas[2, :] - 1/tau + (1/tau**3) * (y[t] - X[i])**2))) - Alphas_n[1, i] * Alphas_n[2, i].T for i in range(N)]
                Betas_n[:, 2, 1] = Betas_n[:, 1, 2]
                Betas_n[:, 2, 2] = [np.sum(wf[i, :] / sum_f[i] * ((Betas[:, 2, 2] + 1/tau**2 - 3 * (y[t] - X[i])**2 / (tau**4)) + (Alphas[2, :] - 1/tau + (1/tau**3) * (y[t] - X[i])**2)**2)) - Alphas_n[2, i] * Alphas_n[2, i].T for i in range(N)]

                Alphas = Alphas_n
                Betas = Betas_n
                # Score estimate
                Sn[t, :] = np.mean(Alphas, axis=1)

                ########################
                # Hessian
                Sigma[t, :, :] = -np.cov(Alphas,bias=True) - np.mean(Betas, axis=0)
              
            thetalist=np.append(thetalist,[thetalist[-1]+(nI+1)**(-2/3)*np.linalg.inv(Sigma[-1,:,:]).dot(Sn[-1]) ],axis=0)
        self.thetalist = thetalist
        
    def onON2(self,ini,c1,A,alpha,N,REP):   
        thetalist=np.array([ini])#[]?
        T=self.T
        y=self.y
        for rep in range(REP):
            phi,sigma,tau=thetalist[-1]
            sigma0=(1-phi**2)**-0.5*sigma
            X = np.random.normal(0, np.sqrt((sigma**2) / (1 - phi**2)), N)  # Initialise
            Alphas = np.zeros((3, N))  # dlogP(x_n,y_1:n)
            Sn = np.zeros((T, 3))  # dlogP(y_1:n)
            Alphas[0, :] = -phi / (1 - phi**2) + phi * (X / sigma)**2
            Alphas[1, :] = -1 / sigma + (1 - phi**2) * X**2 / sigma**3
            Sn[0, :] = np.mean(Alphas, axis=1)
            S_o=Sn[0, :]

            for t in range(1, T):
                an=T*c1/((t+A+rep*T)**alpha)
                phi,sigma,tau=thetalist[-1]
                w0 = -(y[t]- phi * X)**2/2/(sigma**2 + tau**2)
                weights = np.exp(w0 - np.max(w0))
                k = np.random.choice(range(N), size=N, replace=True, p=weights / np.sum(weights))  # Resample
                X1 = X
                omega2 = 1 / (1 / sigma**2 + 1 / tau**2)
                mu = omega2 * (y[t] / tau**2 + phi * X1[k] / sigma**2)
                X = np.random.normal(mu, np.sqrt(omega2))

                # Calculate w[t]f_theta(X[t]|X[t-1])
                xtemp = np.tile(X, (N, 1)).T
                x1temp = np.tile(phi * X1, (N, 1))#.T
                #print(xtemp,x1temp)
                wf = xtemp - x1temp
                wf = np.exp(-0.5 * wf**2 /sigma**2) / np.sqrt(2 * np.pi * sigma**2) #?
                sum_f = np.sum(wf, axis=1)

                # Estimate the joint score 
                Alphas_n = Alphas.copy()  # concern over updating alpha whilst running the recursions
                Alphas_n[0, :] = [np.sum(wf[i, :] * (Alphas[0, :] + (X1 / sigma**2) * (X[i] - phi * X1)))/sum_f[i] for i in range(N)]
                Alphas_n[1, :] = [np.sum(wf[i, :] * (Alphas[1, :] - 1/sigma + (X[i] - phi * X1)**2 / sigma**3))/sum_f[i] for i in range(N)]
                Alphas_n[2, :] = [np.sum(wf[i, :] * (Alphas[2, :] - 1/tau + (1/tau**3) * (y[t] - X[i])**2))/sum_f[i] for i in range(N)]

            
                Alphas = Alphas_n
                Sn[t, :] = np.mean(Alphas, axis=1)


                thetalist=np.append(thetalist,[thetalist[-1]+an*(Sn[t]-S_o) ],axis=0)
                S_o=Sn[t]
        self.thetalist = thetalist
 #bt proposal    
    def ON(self,ini,I,N):   
        thetalist=np.array([ini])#[]?
        T=self.T
        y=self.y
        for nI in range(I):
            phi,sigmax,sigmay=thetalist[-1]
            sigma0=(1-phi**2)**-0.5*sigmax
            X=np.random.normal(0,sigma0,N)  #q(x0|y0=mu(x0))
            log_w=-(y[0]-X)**2/2/sigmay**2
            ind=AR1.resample(log_w)
            X=X[ind]
             
            Alphas = np.zeros((3, N))  # dlogP(x_n,y_1:n)
            Sn = np.zeros((T, 3))  # dlogP(y_1:n)
            Betas = np.zeros((N, 3, 3))  # dlog2(p(x_1:T,y_1:T))
            Sigma = np.zeros((T, 3, 3))  # -dlog2(p(y_1:T))
            Alphas[0] = -phi / (1 - phi**2) + phi * (X / sigmax)**2
            Alphas[1] = -1 / sigmax + (1 - phi**2) * X**2 / sigmax**3
            Alphas[2]=(y[0]-X)**2/sigmay**3-1/sigmay
            #print(X.shape)
            Betas[:, 0, 0] = (X / sigmax)**2 - 1 / (1 - phi**2) - 2 * phi**2 / (1 - phi**2)**2
            Betas[:, 0, 1] = -2 * phi * X**2 / sigmax**3
            Betas[:, 1, 0] = Betas[:, 0, 1]
            Betas[:, 1, 1] = 1 / (sigmax**2) - 3 * X**2 * (1 - phi**2) / (sigmax**4)
            Betas[:, 2, 2] =-3*(y[0]-X)**2/sigmay**4 +1/sigmay**2
            Sn[0, :] = np.mean(Alphas, axis=1)
            Sigma[0, :, :] = -np.cov(Alphas,bias=True) - np.mean(Betas, axis=0)
            for t in np.arange(1,T):
                X_tem=np.random.normal(phi*X,sigmax,N) 
                log_w=-(y[t]-X_tem)**2/2/sigmay**2
                #X=np.append(X,[X_tem],axis=0)
                ind=AR1.resample(log_w)
                X=X[ind]
                X_tem=X_tem[ind]
                Alphas=Alphas[:,ind]
                Betas=Betas[ind,:,:]
                Alphas[0]+=X*(X_tem-phi*X)/sigmax**2
                Alphas[1]+=(X_tem-phi*X)**2/sigmax**3-1/sigmax
                Alphas[2]+=(y[t]-X_tem)**2/sigmay**3   -1/sigmay
                Betas[:,0,0]+=-X**2/sigmax**2
                Betas[:,0,1]+=-2*X*(X_tem-phi*X)/sigmax**3
                Betas[:,1,0]=Betas[:,0,1]
                #Betas[:,0,2]+=-X**2/sigmax**2
                #Betas[:,2,0]+=-X**2/sigmax**2
                Betas[:,1,1]+=-3*(X_tem-phi*X)**2/sigmax**4+1/sigmax**2
               # Betas[:,1,2]+=-X**2/sigmax**2
                #Betas[:,2,1]+=-X**2/sigmax**2
                Betas[:,2,2]+=-3*(y[t]-X_tem)**2/sigmay**4+1/sigmay**2
                Sn[t, :] = np.mean(Alphas, axis=1)
                Sigma[t, :, :] = -np.cov(Alphas,bias=True) - np.mean(Betas, axis=0)
                X=X_tem


                #test=Sn[t, :].reshape(3,1).dot([Sn[t, :]])-Alphas.dot(Alphas.T)/N - np.mean(Betas, axis=0)
                #print(test-Sigma[t])
            #grad_phi=np.sum(X[:-1]*(X[1:]-phi*X[:-1]))/sigmax**2/N -phi / (1 - phi**2) + phi * np.mean(X**2) / sigmax**2
            #grad_sx=np.sum((X[1:]-phi*X[:-1])**2)/sigmax**3/N-T/sigmax +(1-phi**2)*np.mean(X**2)/sigmax**3
            #grad_sy=np.sum((y[:,None]-X)**2)/sigmay**3/N-(T)/sigmay
            
            #grad=np.array([grad_phi,grad_sx,grad_sy])
            #print(Sn[-1]-grad,'diff')
            
            #log_w=np.zeros(N)
            #grad_phi=np.sum(X[:-1]*(X[1:]-phi*X[:-1]))/sigmax**2/N -phi / (1 - phi**2) + phi * np.mean(X**2) / sigmax**2
            #grad_sx=np.sum((X[1:]-phi*X[:-1])**2)/sigmax**3/N-T/sigmax -1/sigmax+(1-phi**2)*np.mean(X**2)/sigmax**3
            #grad_sy=np.sum((y[:,None]-X)**2)/sigmay**3/N-(T+1)/sigmay
            
            #grad=np.array([grad_phi,grad_sx,grad_sy])
            #print(grad)
            #an=c1/((nI+A)**alpha)
            #thetalist=np.append(thetalist,[thetalist[-1]+an*Sn[-1] ],axis=0)
            
            #test_S[0,0]=
            #print(np.mean(Betas, axis=0))
            #print(Sigma[-1])
            #print(np.linalg.inv(Sigma[-1]))
            thetalist=np.append(thetalist,[thetalist[-1]+(nI+1)**(-2/3)*np.linalg.inv(Sigma[-1]).dot(Sn[-1]) ],axis=0)
            #print(thetalist[-1])
        self.thetalist = thetalist

     #opt proposal
    def ON1(self,ini,I,N):   
        thetalist=np.array([ini])#[]?
        T=self.T
        y=self.y
        for nI in range(I):
            phi,sigmax,sigmay=thetalist[-1]
            sigma0=(1-phi**2)**-0.5*sigmax
            v_tot=sigma0**2+sigmay**2
            v_con=1/(sigma0**-2+sigmay**-2)
            mu=y[0]*sigma0**2/v_tot
            X=np.random.normal(mu,v_con**.5,N)
             
            Alphas = np.zeros((3, N))  # dlogP(x_n,y_1:n)
            Sn = np.zeros((T, 3))  # dlogP(y_1:n)
            Betas = np.zeros((N, 3, 3))  # dlog2(p(x_1:T,y_1:T))
            Sigma = np.zeros((T, 3, 3))  # -dlog2(p(y_1:T))
            Alphas[0] = -phi / (1 - phi**2) + phi * (X / sigmax)**2
            Alphas[1] = -1 / sigmax + (1 - phi**2) * X**2 / sigmax**3
            Alphas[2]=(y[0]-X)**2/sigmay**3-1/sigmay
            #print(X.shape)
            Betas[:, 0, 0] = (X / sigmax)**2 - 1 / (1 - phi**2) - 2 * phi**2 / (1 - phi**2)**2
            Betas[:, 0, 1] = -2 * phi * X**2 / sigmax**3
            Betas[:, 1, 0] = Betas[:, 0, 1]
            Betas[:, 1, 1] = 1 / (sigmax**2) - 3 * X**2 * (1 - phi**2) / (sigmax**4)
            Betas[:, 2, 2] =-3*(y[0]-X)**2/sigmay**4 +1/sigmay**2
            Sn[0, :] = np.mean(Alphas, axis=1)
            Sigma[0, :, :] = -np.cov(Alphas,bias=True) - np.mean(Betas, axis=0)
            for t in np.arange(1,T):
                v_con=1/(sigmax**-2+sigmay**-2)
                v_tot=sigmax**2+sigmay**2
                mu=phi*X*sigmay**2/v_tot+y[t]*sigmax**2/v_tot
                diff=y[t]-phi*X
                X_tem=np.random.normal(mu,v_con**.5,N) 
                log_w=-diff**2/2/v_tot
                ind=AR1.resample(log_w)
                X=X[ind]
                X_tem=X_tem[ind]
                Alphas=Alphas[:,ind]
                Betas=Betas[ind,:,:]
                Alphas[0]+=X*(X_tem-phi*X)/sigmax**2
                Alphas[1]+=(X_tem-phi*X)**2/sigmax**3-1/sigmax
                Alphas[2]+=(y[t]-X_tem)**2/sigmay**3   -1/sigmay
                Betas[:,0,0]+=-X**2/sigmax**2
                Betas[:,0,1]+=-2*X*(X_tem-phi*X)/sigmax**3
                Betas[:,1,0]=Betas[:,0,1]
                #Betas[:,0,2]+=-X**2/sigmax**2
                #Betas[:,2,0]+=-X**2/sigmax**2
                Betas[:,1,1]+=-3*(X_tem-phi*X)**2/sigmax**4+1/sigmax**2
               # Betas[:,1,2]+=-X**2/sigmax**2
                #Betas[:,2,1]+=-X**2/sigmax**2
                Betas[:,2,2]+=-3*(y[t]-X_tem)**2/sigmay**4+1/sigmay**2
                Sn[t, :] = np.mean(Alphas, axis=1)
                Sigma[t, :, :] = -np.cov(Alphas,bias=True) - np.mean(Betas, axis=0)
                X=X_tem


                #test=Sn[t, :].reshape(3,1).dot([Sn[t, :]])-Alphas.dot(Alphas.T)/N - np.mean(Betas, axis=0)
                #print(test-Sigma[t])
            #grad_phi=np.sum(X[:-1]*(X[1:]-phi*X[:-1]))/sigmax**2/N -phi / (1 - phi**2) + phi * np.mean(X**2) / sigmax**2
            #grad_sx=np.sum((X[1:]-phi*X[:-1])**2)/sigmax**3/N-T/sigmax +(1-phi**2)*np.mean(X**2)/sigmax**3
            #grad_sy=np.sum((y[:,None]-X)**2)/sigmay**3/N-(T)/sigmay
            
            #grad=np.array([grad_phi,grad_sx,grad_sy])
            #print(Sn[-1]-grad,'diff')
            
            #log_w=np.zeros(N)
            #grad_phi=np.sum(X[:-1]*(X[1:]-phi*X[:-1]))/sigmax**2/N -phi / (1 - phi**2) + phi * np.mean(X**2) / sigmax**2
            #grad_sx=np.sum((X[1:]-phi*X[:-1])**2)/sigmax**3/N-T/sigmax -1/sigmax+(1-phi**2)*np.mean(X**2)/sigmax**3
            #grad_sy=np.sum((y[:,None]-X)**2)/sigmay**3/N-(T+1)/sigmay
            
            #grad=np.array([grad_phi,grad_sx,grad_sy])
            #print(grad)
            #an=c1/((nI+A)**alpha)
            #thetalist=np.append(thetalist,[thetalist[-1]+an*Sn[-1] ],axis=0)
            
            #test_S[0,0]=
            #print(np.mean(Betas, axis=0))
            #print(Sigma[-1])
            #print(np.linalg.inv(Sigma[-1]))
            thetalist=np.append(thetalist,[thetalist[-1]+(nI+1)**(-2/3)*np.linalg.inv(Sigma[-1]).dot(Sn[-1]) ],axis=0)
            #print(thetalist[-1])
        self.thetalist = thetalist

        #with r2 resampling control,bt proposal    
    def onGA1(self,ini,c1,A,alpha,N,r1,r2,REP):
        thetalist=np.array([ini])
        T=self.T
        y=self.y
        
        k1=0
        renew_t=[]
        #phi_l,sigmax_l,sigmay_l=ini
        for rep in range(REP):
            phi_l,sigmax_l,sigmay_l=thetalist[-1]
            phi,sigmax,sigmay=thetalist[-1]
            sigma0=(1-phi**2)**-0.5*sigmax
            X=np.random.normal(0,sigma0,N)  #q(x0|y0=mu(x0))
            log_w=-(y[0]-X)**2/2/sigmay**2
            ind=AR1.resample(log_w)
            X=X[ind]
            X0=X
            X1_sq=np.zeros(N)
            X1__1=np.zeros(N)
            X_1sq=np.zeros(N)
            y_x=(y[0]-X)**2
            log_w=np.zeros(N)
            for t in np.arange(1,T):
            
                #propagation
                an=T*c1/(t+A+rep*T)**alpha#a_t=(T+1)*c1/((rep*T+t+A)**alpha)
                phi,sigmax,sigmay=thetalist[-1]

                X_tem=np.random.normal(phi*X,sigmax,N)

                #oldgrad
                #print(t,thetalist[-1][0])
                #print(X[:-1])
                vec2_phi=X1__1-phi*X_1sq  + phi *(X0**2) 
                grad2_phi=AR1.fisher(vec2_phi,log_w)/sigmax**2
                vec2_s=X1_sq-2*phi*X1__1+phi**2*X_1sq
                vec2_sx=vec2_s+(1-phi**2)*(X0**2)
                grad2_sx=AR1.fisher(vec2_sx,log_w)/sigmax**3
                vec2_sy=y_x
                grad2_sy=AR1.fisher(vec2_sy,log_w)/sigmay**3

                inc=(y[t]-X_tem)**2
                log_w-=inc/2/sigmay**2
                X1_sq+=X_tem**2
                X1__1+=X*X_tem
                X_1sq+=X**2
                y_x+=inc
                
                vec1_phi=vec2_phi+X*(X_tem-phi*X) 
                vec1_sx=vec2_sx+(X_tem-phi*X)**2
                vec1_sy=y_x



                grad1_phi=AR1.fisher(vec1_phi,log_w)/sigmax**2
                grad1_sx=AR1.fisher(vec1_sx,log_w)/sigmax**3
                grad1_sy=AR1.fisher(vec1_sy,log_w)/sigmay**3

                grad_phi=grad1_phi-grad2_phi
                grad_sx=grad1_sx-grad2_sx-1/sigmax
                grad_sy=grad1_sy-grad2_sy-1/sigmay
                #grad_sx,grad_sy=0,0
                grad=np.array([grad_phi,grad_sx,grad_sy])

                thetalist=np.append(thetalist,[thetalist[-1]+an*grad],axis=0)

                #
                vec2_s=X1_sq-2*phi*X1__1+phi**2*X_1sq
                islogw=AR1.getisw(X0**2,X1_sq,X1__1,X_1sq,phi,sigmax,sigmay,phi_l,sigmax_l,sigmay_l,vec2_s,y_x)
                rtgt_logw=AR1.getisw(X0**2,X1_sq,X1__1,X_1sq,phi,sigmax,sigmay,thetalist[-2][0],thetalist[-2][1],thetalist[-2][2],vec2_s,y_x)         
                log_w+=rtgt_logw


                ess_a=AR1.ess(islogw)/N
                ess_w=AR1.ess(log_w)/N
                
                X=X_tem


                #print(ess_a,ess_w)          
                if(ess_a<r1):
                    k1+=1
                    renew_t.append([t+rep*T])
                    phi_l,sigmax_l,sigmay_l=thetalist[-1]
                    sigma0_l=(1-phi_l**2)**-0.5*sigmax_l
                    X=np.random.normal(0,sigma0_l,N)   #q(x0|y0=mu(x0))
                    log_w=-(y[0]-X)**2/2/sigmay_l**2
                    ind=AR1.resample(log_w)
                    X=X[ind]
                    X0=X
                    X1_sq=np.zeros(N)
                    X1__1=np.zeros(N)
                    X_1sq=np.zeros(N)
                    y_x=(y[0]-X)**2
                    for t1 in np.arange(1,t+1):
                        X_tem=np.random.normal(phi_l*X,sigmax_l,N)#bootstrap,q(xt|xt-1,yt)=f(xt|xt-1))
                        inc=(y[t1]-X_tem)**2
                        log_w=-inc/2/sigmay_l**2
                        X1_sq+=X_tem**2
                        X1__1+=X*X_tem
                        X_1sq+=X**2
                        y_x+=inc
                        ind=AR1.resample(log_w)
                        X=X_tem[ind]
                        X1_sq=X1_sq[ind]
                        X1__1=X1__1[ind]
                        X_1sq=X_1sq[ind]
                        y_x=y_x[ind]
                        X0=X0[ind]
                    log_w=np.zeros(N)

                elif(ess_w<r2):
                    ind=AR1.resample(log_w)
                    X=X[ind]
                    X1_sq=X1_sq[ind]
                    X1__1=X1__1[ind]
                    X_1sq=X_1sq[ind]
                    y_x=y_x[ind]
                    X0=X0[ind]
                    log_w=np.zeros(N)
        print(k1)
        self.renew_t=renew_t
        self.k1=k1
        self.thetalist = thetalist 
        #with r2 resampling control,opt proposal    
    def onGA2(self,ini,c1,A,alpha,N,r1,r2,REP):
        thetalist=np.array([ini])
        T=self.T
        y=self.y
        
        k1=0
        renew_t=[]
        #phi_l,sigmax_l,sigmay_l=ini
        for rep in range(REP):
            phi_l,sigmax_l,sigmay_l=thetalist[-1]
            phi,sigmax,sigmay=thetalist[-1]
            sigma0=(1-phi**2)**-0.5*sigmax
            v_tot=sigma0**2+sigmay**2
            v_con=1/(sigma0**-2+sigmay**-2)
            mu=y[0]*sigma0**2/v_tot
            X=np.random.normal(mu,v_con**.5,N)
            X0=X
            X1_sq=np.zeros(N)
            X1__1=np.zeros(N)
            X_1sq=np.zeros(N)
            y_x=(y[0]-X)**2
            log_w=np.zeros(N)
            for t in np.arange(1,T):
            
                #propagation
                an=T*c1/(t+A+rep*T)**alpha#a_t=(T+1)*c1/((rep*T+t+A)**alpha)
                phi,sigmax,sigmay=thetalist[-1]
                
                v_con=1/(sigmax**-2+sigmay**-2)
                v_tot=sigmax**2+sigmay**2
                mu=phi*X*sigmay**2/v_tot+y[t]*sigmax**2/v_tot
                diff=y[t]-phi*X
                X_tem=np.random.normal(mu,v_con**.5,N) 
                
                

                

                #oldgrad
                #print(t,thetalist[-1][0])
                #print(X[:-1])
                vec2_phi=X1__1-phi*X_1sq  + phi *(X0**2) 
                grad2_phi=AR1.fisher(vec2_phi,log_w)/sigmax**2
                vec2_s=X1_sq-2*phi*X1__1+phi**2*X_1sq
                vec2_sx=vec2_s+(1-phi**2)*(X0**2)
                grad2_sx=AR1.fisher(vec2_sx,log_w)/sigmax**3
                vec2_sy=y_x
                grad2_sy=AR1.fisher(vec2_sy,log_w)/sigmay**3

                inc=(y[t]-X_tem)**2
                log_w-=diff**2/2/v_tot
                X1_sq+=X_tem**2
                X1__1+=X*X_tem
                X_1sq+=X**2
                y_x+=inc
                
                vec1_phi=vec2_phi+X*(X_tem-phi*X) 
                vec1_sx=vec2_sx+(X_tem-phi*X)**2
                vec1_sy=y_x



                grad1_phi=AR1.fisher(vec1_phi,log_w)/sigmax**2
                grad1_sx=AR1.fisher(vec1_sx,log_w)/sigmax**3
                grad1_sy=AR1.fisher(vec1_sy,log_w)/sigmay**3

                grad_phi=grad1_phi-grad2_phi
                grad_sx=grad1_sx-grad2_sx-1/sigmax
                grad_sy=grad1_sy-grad2_sy-1/sigmay
                #grad_sx,grad_sy=0,0
                grad=np.array([grad_phi,grad_sx,grad_sy])

                thetalist=np.append(thetalist,[thetalist[-1]+an*grad],axis=0)

                #
                vec2_s=X1_sq-2*phi*X1__1+phi**2*X_1sq
                islogw=AR1.getisw(X0**2,X1_sq,X1__1,X_1sq,phi,sigmax,sigmay,phi_l,sigmax_l,sigmay_l,vec2_s,y_x)
                rtgt_logw=AR1.getisw(X0**2,X1_sq,X1__1,X_1sq,phi,sigmax,sigmay,thetalist[-2][0],thetalist[-2][1],thetalist[-2][2],vec2_s,y_x)         
                log_w+=rtgt_logw


                ess_a=AR1.ess(islogw)/N
                ess_w=AR1.ess(log_w)/N
                
                X=X_tem


                #print(ess_a,ess_w)          
                if(ess_a<r1):
                    k1+=1
                    renew_t.append([t+rep*T])
                    phi_l,sigmax_l,sigmay_l=thetalist[-1]
                    sigma0_l=(1-phi_l**2)**-0.5*sigmax_l
                    v_tot=sigma0_l**2+sigmay_l**2
                    v_con=1/(sigma0_l**-2+sigmay_l**-2)
                    mu=y[0]*sigma0_l**2/v_tot
                    X=np.random.normal(mu,v_con**.5,N)
                    X0=X
                    X1_sq=np.zeros(N)
                    X1__1=np.zeros(N)
                    X_1sq=np.zeros(N)
                    y_x=(y[0]-X)**2
                    for t1 in np.arange(1,t+1):
                        v_con=1/(sigmax_l**-2+sigmay_l**-2)
                        v_tot=sigmax_l**2+sigmay_l**2
                        mu=phi_l*X*sigmay_l**2/v_tot+y[t]*sigmax_l**2/v_tot
                        diff=y[t]-phi_l*X
                        X_tem=np.random.normal(mu,v_con**.5,N) 
                        log_w=-diff**2/2/v_tot                        
                        inc=(y[t1]-X_tem)**2
                        X1_sq+=X_tem**2
                        X1__1+=X*X_tem
                        X_1sq+=X**2
                        y_x+=inc
                        ind=AR1.resample(log_w)
                        X=X_tem[ind]
                        X1_sq=X1_sq[ind]
                        X1__1=X1__1[ind]
                        X_1sq=X_1sq[ind]
                        y_x=y_x[ind]
                        X0=X0[ind]
                    log_w=np.zeros(N)

                elif(ess_w<r2):
                    ind=AR1.resample(log_w)
                    X=X[ind]
                    X1_sq=X1_sq[ind]
                    X1__1=X1__1[ind]
                    X_1sq=X_1sq[ind]
                    y_x=y_x[ind]
                    X0=X0[ind]
                    log_w=np.zeros(N)
        #print(k1)
        self.renew_t=renew_t
        self.k1=k1
        self.thetalist = thetalist 