#This file contains algorithms used for the SV model, corresponding to section 5.2 in the paper.
import numpy as np

class SV:
    def __init__(self,y):
        self.y=y
        self.T=len(y)
    
    @staticmethod
    def logsumexp(log_w):
        val=np.log(np.sum(np.exp(log_w)))
        return val
        
    @staticmethod
    def normalize_log_w(log_w):
        log_w -= np.max(log_w)
        w = np.exp(log_w)
        w /= np.sum(w)
        return w
    
    @staticmethod
    def fisher(vec,log_w):
        log_w -= np.max(log_w)
        w = np.exp(log_w)
        val=np.sum(vec*w)/np.sum(w)
        return val

    @staticmethod
    def ess(log_w):
        w = SV.normalize_log_w(log_w)
        return 1 / np.sum(w ** 2)

    @staticmethod
    def resample(log_w):
        N = len(log_w)
        #
        log_w-=np.max(log_w)
        index = np.random.choice(np.arange(N), size=N, p=SV.normalize_log_w(log_w))
        return index
    @staticmethod
    def getisw(X02,X1_sq,X1__1,X_1sq,phi,sigmax,sigmay,phi_l,sigmax_l,sigmay_l,vec2_s,vec3):       
        islogw0=X02 *(-(1-phi**2)/2/sigmax**2+(1-phi_l**2)/2/sigmax_l**2)
        islogwx=-vec2_s/2/sigmax**2+(X1_sq-2*phi_l*X1__1+phi_l**2*X_1sq)/2/sigmax_l**2        
        islogwy=(-1/2/sigmay**2+1/2/sigmay_l**2)*vec3 
        val=islogw0+islogwx+islogwy   
    @staticmethod
    def getisw(X02,X1_sq,X1__1,X_1sq,phi,sigmax,sigmay,phi_l,sigmax_l,sigmay_l,vecy_x):       
        islogw0=X02 *(-(1-phi**2)/2/sigmax**2+(1-phi_l**2)/2/sigmax_l**2)
        islogwx=-(X1_sq-2*phi*X1__1+phi**2*X_1sq)/2/sigmax**2+(X1_sq-2*phi_l*X1__1+phi_l**2*X_1sq)/2/sigmax_l**2        
        islogwy=(-1/2/sigmay**2+1/2/sigmay_l**2)*vecy_x 
        val=islogw0+islogwx+islogwy  
        
        return val

    #llhd estimate
    def llhd(self,phi,sigmax,sigmay,N):
        y=self.y
        T=self.T
        sigma0=(1-phi**2)**-0.5*sigmax           
        X=np.random.normal(0,sigma0,N)  #q(x0|y0=mu(x0))
        log_w=-np.log(sigmay)-X/2-(y[0])**2*np.exp(-X)/2/sigmay**2
        ind=SV.resample(log_w)
        X=X[ind]
        llhd=SV.logsumexp(log_w)
        for t in np.arange(1,T):
            X_tem=np.random.normal(phi*X,sigmax,N) 
            log_w=-np.log(sigmay)-X_tem/2-(y[t])**2*np.exp(-X_tem)/2/sigmay**2
            #X_f=np.append(X_f,[X_f_tem],axis=0)
            ind=SV.resample(log_w)
            X=X_tem[ind]  
            llhd+=SV.logsumexp(log_w)
        return(llhd)
        
    def NGA(self,ini,c1,c2,A,alpha,gamma,I,N):
        thetalist=np.array([ini])#[]?
        y=self.y
        T=self.T
        for nI in range(I):
            an=c1/((nI+A)**alpha)
            cn=c2/((nI+1)**gamma)
            delta=2*np.random.binomial(1,[.5]*3)-1
            phi_f,sigmax_f,sigmay_f=thetalist[-1]+delta*cn
            sigma0_f=(1-phi_f**2)**-0.5*sigmax_f           
            X_f=np.random.normal(0,sigma0_f,N)  #q(x0|y0=mu(x0))
            log_w_f=-np.log(sigmay_f)-X_f/2-(y[0])**2*np.exp(-X_f)/2/sigmay_f**2
            ind_f=SV.resample(log_w_f)
            X_f=X_f[ind_f]
            phi_b,sigmax_b,sigmay_b=thetalist[-1]-delta*cn
            sigma0_b=(1-phi_b**2)**-0.5*sigmax_b           
            X_b=np.random.normal(0,sigma0_b,N)  #q(x0|y0=mu(x0))
            log_w_b=-np.log(sigmay_b)-X_b/2-(y[0])**2*np.exp(-X_b)/2/sigmay_b**2
            ind_b=SV.resample(log_w_b)
            X_b=X_b[ind_b]
            l_f=SV.logsumexp(log_w_f)
            l_b=SV.logsumexp(log_w_b)
            for t in np.arange(1,T):
                X_f_tem=np.random.normal(phi_f*X_f,sigmax_f,N) 
                log_w_f=-np.log(sigmay_f)-X_f_tem/2-(y[t])**2*np.exp(-X_f_tem)/2/sigmay_f**2
                #X_f=np.append(X_f,[X_f_tem],axis=0)
                ind_f=SV.resample(log_w_f)
                X_f=X_f_tem[ind_f]  
                l_f+=SV.logsumexp(log_w_f)
                X_b_tem=np.random.normal(phi_b*X_b,sigmax_b,N) 
                log_w_b=-np.log(sigmay_b)-X_b_tem/2-(y[t])**2*np.exp(-X_b_tem)/2/sigmay_b**2
                #X_b=np.append(X_b,[X_b_tem],axis=0)
                ind_b=SV.resample(log_w_b)
                X_b=X_b_tem[ind_b] 
                l_b+=SV.logsumexp(log_w_b)
                
            grad=(l_f-l_b)/2/cn/delta
            thetalist=np.append(thetalist,[thetalist[-1]+an*grad],axis=0)
        self.thetalist = thetalist
        
        
    #bt proposal    
    def FGA(self,ini,c1,A,alpha,I,N):   
        thetalist=np.array([ini])#[]?
        y=self.y
        T=self.T
        for nI in range(I):
            phi,sigmax,sigmay=thetalist[-1]
            sigma0=(1-phi**2)**-0.5*sigmax
            an=c1/((nI+A)**alpha)
            X=np.random.normal(0,sigma0,N)  #q(x0|y0=mu(x0))
            log_w=-X/2-(y[0])**2*np.exp(-X)/2/sigmay**2
            ind=SV.resample(log_w)
            X=X[ind]
            v_phi= phi *X**2
            v_sx=(1-phi**2)*X**2
            v_sy=(y[0])**2*np.exp(-X)
            for t in np.arange(1,T):
                X_tem=np.random.normal(phi*X,sigmax,N) 
                log_w=-X_tem/2-(y[t])**2*np.exp(-X_tem)/2/sigmay**2
                #X=np.append(X,[X_tem],axis=0)
                v_phi+=X*(X_tem-phi*X)
                v_sx+=(X_tem-phi*X)**2
                v_sy+=(y[t])**2*np.exp(-X_tem)
                
                
                ind=SV.resample(log_w)
                X=X_tem[ind]
                v_phi=v_phi[ind]
                v_sx=v_sx[ind]
                v_sy=v_sy[ind]
            #grad_phi=np.sum(X[:-1]*(X[1:]-phi*X[:-1]))/sigmax**2/N -phi / (1 - phi**2) + phi * np.mean(X[0]**2) / sigmax**2
            #grad_sx=np.sum((X[1:]-phi*X[:-1])**2)/sigmax**3/N-T/sigmax +(1-phi**2)*np.mean(X[0]**2)/sigmax**3
            #grad_sy=np.sum((y[:,None]-X)**2)/sigmay**3/N-(T)/sigmay
            
            grad_phi=np.mean(v_phi)/sigmax**2 -phi / (1 - phi**2)
            grad_sx=np.mean(v_sx)/sigmax**3-T/sigmax
            grad_sy=np.mean(v_sy)/sigmay**3-T/sigmay
            
            grad=np.array([grad_phi,grad_sx,grad_sy])
            #print(grad)
            thetalist=np.append(thetalist,[thetalist[-1]+an*grad],axis=0)
        self.thetalist = thetalist
        
    
      

        #AGA reduced cost,bt
    def AGA(self,ini,c1,A,alpha,I,N,r,inner_K):   
        thetalist=np.array([ini])
        y=self.y
        T=self.T
        n=0
        for nI in range(I):
            k=0
            ess=2
            
            phi_l,sigmax_l,sigmay_l=thetalist[-1]
            sigma0_l=(1-phi_l**2)**-0.5*sigmax_l
            X=np.random.normal(0,sigma0_l,N)  #q(x0|y0=mu(x0))
            log_w=-X/2-(y[0])**2*np.exp(-X)/2/sigmay_l**2
            ind=SV.resample(log_w)
            X=X[ind]
            X0=X
            X1_sq=np.zeros(N)
            X1__1=np.zeros(N)
            X_1sq=np.zeros(N)
            y_x=(y[0])**2*np.exp(-X)
            
            
            
            for t in np.arange(1,T):             
                X_tem=np.random.normal(phi_l*X,sigmax_l,N) 
                log_w=-X_tem/2-(y[t])**2*np.exp(-X_tem)/2/sigmay_l**2
                #X=np.append(X,[X_tem],axis=0)
                
                X1_sq+=X_tem**2
                X1__1+=X*X_tem
                X_1sq+=X**2
                y_x+=(y[t])**2*np.exp(-X_tem)
                
                
                ind=SV.resample(log_w)
                X=X_tem[ind]
                X1_sq=X1_sq[ind]
                X1__1=X1__1[ind]
                X_1sq=X_1sq[ind]
                y_x=y_x[ind]
                X0=X0[ind]
                
            islogw=np.zeros(N)
            while ((ess > r)&(k<inner_K)):
                n+=1
                k+=1
                an=c1/((n+A)**alpha)
                phi,sigmax,sigmay=thetalist[-1]
                
                
                
                #vec1=np.sum(X[:-1]*(X[1:]-phi*X[:-1]),axis=0)                
                #vec1=np.sum(X[:-1]*(X[1:]-phi*X[:-1]),axis=0)  + phi *(X[0]**2) / sigmax**2
            
                vec1=X1__1-phi*X_1sq  + phi *(X0**2) 
                grad_phi=SV.fisher(vec1,islogw)/sigmax**2-phi / (1 - phi**2)
                
                #vec2=np.sum((X[1:]-phi*X[:-1])**2,axis=0) 
                #vec2=np.sum((X[1:]-phi*X[:-1])**2,axis=0) -1/sigmax+(1-phi**2)*(X[0]**2)/sigmax**3
                vec2_s=X1_sq-2*phi*X1__1+phi**2*X_1sq
                vec2=vec2_s/sigmax**3 -1/sigmax+(1-phi**2)*(X0**2)/sigmax**3
                grad_sx=SV.fisher(vec2,islogw)-(T-1)/sigmax
                
                vec3=y_x
                grad_sy=SV.fisher(vec3,islogw)/sigmay**3-T/sigmay
                grad=np.array([grad_phi,grad_sx,grad_sy])
                
                thetalist=np.append(thetalist,[thetalist[-1]+an*grad],axis=0)
                
                
                #islogwx=-np.sum((X[1:]-phi*X[:-1])**2,axis=0)/2/sigmax**2+np.sum((X[1:]-phi_l*X[:-1])**2,axis=0)/2/sigmax_l**2      
                #islogwy=(-1/2/sigmay**2+1/2/sigmay_l**2)*vec3
                #islogw=islogwx+islogwy
                islogw=SV.getisw(X0**2,X1_sq,X1__1,X_1sq,phi,sigmax,sigmay,phi_l,sigmax_l,sigmay_l,vec3)
                ess=SV.ess(islogw)/N
            #print(k)
        self.thetalist = thetalist 
               
    def onON2(self,ini,c1,A,alpha,N,REP):   
        thetalist=np.array([ini])#[]?
        y=self.y
        T=self.T
        for rep in range(REP):
            phi,sigma,tau=thetalist[-1]
            sigma0=(1-phi**2)**-0.5*sigma
            X=np.random.normal(0,sigma0,N)  #q(x0|y0=mu(x0))
            log_w=-X/2-(y[0])**2*np.exp(-X)/2/sigma**2
            ind=SV.resample(log_w)
            X=X[ind]  # Initialise
            Alphas = np.zeros((3, N))  # dlogP(x_n,y_1:n)
            Sn = np.zeros((T, 3))  # dlogP(y_1:n)
            Betas = np.zeros((N, 3, 3))  # dlog2(p(x_1:T,y_1:T))
            Sigma = np.zeros((T, 3, 3))  # -dlog2(p(y_1:T))
            Alphas[0, :] = -phi / (1 - phi**2) + phi * (X / sigma)**2
            Alphas[1, :] = -1 / sigma + (1 - phi**2) * X**2 / sigma**3
            Alphas[2, :] = -1 / tau + y[0]**2*np.exp(-X) / tau**3  #

            Betas[:, 0, 0] = (X / sigma)**2 - 1 / (1 - phi**2) - 2 * phi**2 / (1 - phi**2)**2
            Betas[:, 0, 1] = -2 * phi * X**2 / sigma**3
            Betas[:, 1, 0] = Betas[:, 0, 1]
            Betas[:, 1, 1] = 1 / (sigma**2) - 3 * X**2 * (1 - phi**2) / (sigma**4)
            Betas[:, 2, 2] = 1 / (tau**2) - 3 * y[0]**2*np.exp(-X) / (tau**4)##
            Sn[0, :] = np.mean(Alphas, axis=1)
            Sigma[0, :, :] = -np.cov(Alphas,bias=True) - np.mean(Betas, axis=0)
            S_o=Sn[0, :]

            for t in range(1, T):
                an=T*c1/((t+A+rep*T)**alpha)
                phi,sigma,tau=thetalist[-1]
                X_tem=np.random.normal(phi*X,sigma,N) 
                log_w=-X_tem/2-(y[t])**2*np.exp(-X_tem)/2/sigma**2
                #X=np.append(X,[X_tem],axis=0)
                ind=SV.resample(log_w)
                X=X[ind]
                X_tem=X_tem[ind]
                Alphas=Alphas[:,ind]
                Betas=Betas[ind,:,:]
                X1=X
                X=X_tem

                # Calculate w[t]f_theta(X[t]|X[t-1])
                xtemp = np.tile(X, (N, 1)).T
                x1temp = np.tile(phi * X1, (N, 1))#.T
                #print(xtemp,x1temp)
                wf = xtemp - x1temp
                wf = np.exp(-0.5 * wf**2 /sigma**2) / np.sqrt(2 * np.pi * sigma**2) #?
                sum_f = np.sum(wf, axis=1)

                # Estimate the joint score 
                Alphas_n = Alphas.copy()  # concern over updating alpha whilst running the recursions
                Alphas_n[0, :] = [np.sum(wf[i, :] * (Alphas[0, :] + (X1 / sigma**2) * (X[i] - phi * X1)))/sum_f[i] for i in range(N)]
                Alphas_n[1, :] = [np.sum(wf[i, :] * (Alphas[1, :] - 1/sigma + (X[i] - phi * X1)**2 / sigma**3))/sum_f[i] for i in range(N)]
                Alphas_n[2, :] = [np.sum(wf[i, :] * (Alphas[2, :] - 1/tau + (1/tau**3) * (y[t])**2*np.exp(-X[i])))/sum_f[i] for i in range(N)]

                # Estimate observed information of joint dist
                Betas_n = Betas.copy()
                Betas_n[:, 0, 0] = [np.sum(wf[i, :] / sum_f[i] * ((Alphas[0, :] + (X1 / sigma**2) * (X[i] - phi * X1))**2 + (Betas[:, 0, 0] - (X1 / sigma)**2))) - Alphas_n[0, i] * Alphas_n[0, i].T for i in range(N)]
                Betas_n[:, 0, 1] = [np.sum(wf[i, :] / sum_f[i] * ((Betas[:, 0, 1] - (2 * X1 / (sigma**3)) * (X[i] - phi * X1)) + (Alphas[0, :] + (X1 / sigma**2) * (X[i] - phi * X1)) * (Alphas[1, :] - 1/sigma + (X[i] - phi * X1)**2 / sigma**3))) - Alphas_n[0, i] * Alphas_n[1, i].T for i in range(N)]
                Betas_n[:, 1, 0] = Betas_n[:, 0, 1]
                Betas_n[:, 0, 2] = [np.sum(wf[i, :] / sum_f[i] * ((Alphas[0, :] + (X1 / sigma**2) * (X[i] - phi * X1)) * (Alphas[2, :] - 1/tau + (1/tau**3) * (y[t])**2*np.exp(-X[i]) ))) - Alphas_n[0, i] * Alphas_n[2, i].T for i in range(N)]
                Betas_n[:, 2, 0] = Betas_n[:, 0, 2]
                Betas_n[:, 1, 1] = [np.sum(wf[i, :] / sum_f[i] * ((Betas[:, 1, 1] + 1/sigma**2 - 3 * (X[i] - phi * X1)**2 / (sigma**4)) + (Alphas[1, :] - 1/sigma + (X[i] - phi * X1)**2 / sigma**3)**2)) - Alphas_n[1, i] * Alphas_n[1, i].T for i in range(N)]
                Betas_n[:, 1, 2] = [np.sum(wf[i, :] / sum_f[i] * ((Alphas[1, :] - 1/sigma + (X[i] - phi * X1)**2 / sigma**3) * (Alphas[2, :] - 1/tau + (1/tau**3) * (y[t])**2*np.exp(-X[i])   ))) - Alphas_n[1, i] * Alphas_n[2, i].T for i in range(N)]
                Betas_n[:, 2, 1] = Betas_n[:, 1, 2]
                Betas_n[:, 2, 2] = [np.sum(wf[i, :] / sum_f[i] * ((Betas[:, 2, 2] + 1/tau**2 - 3 *(y[t])**2*np.exp(-X[i]) / (tau**4)) + (Alphas[2, :] - 1/tau + (1/tau**3) *(y[t])**2*np.exp(-X[i]))**2)) - Alphas_n[2, i] * Alphas_n[2, i].T for i in range(N)]

                Alphas = Alphas_n
                Betas = Betas_n
                # Score estimate
                Sn[t, :] = np.mean(Alphas, axis=1)

                ########################
                # Hessian
                Sigma[t, :, :] = -np.cov(Alphas,bias=True) - np.mean(Betas, axis=0)

                thetalist=np.append(thetalist,[thetalist[-1]+an*(Sn[t]-S_o) ],axis=0)
                S_o=Sn[t]
                #thetalist=np.append(thetalist,[thetalist[-1]+an*Sn[-1] ],axis=0)
                #print(thetalist[-1])
        self.thetalist = thetalist
 #bt proposal    
    def ON(self,ini,I,N):   
        thetalist=np.array([ini])#[]?
        y=self.y
        T=self.T
        for nI in range(I):
            phi,sigmax,sigmay=thetalist[-1]
            sigma0=(1-phi**2)**-0.5*sigmax
            X=np.random.normal(0,sigma0,N)  #q(x0|y0=mu(x0))
            log_w=-X/2-(y[0])**2*np.exp(-X)/2/sigmay**2
            ind=SV.resample(log_w)
            X=X[ind]
             
            Alphas = np.zeros((3, N))  # dlogP(x_n,y_1:n)
            Sn = np.zeros((T, 3))  # dlogP(y_1:n)
            Betas = np.zeros((N, 3, 3))  # dlog2(p(x_1:T,y_1:T))
            Sigma = np.zeros((T, 3, 3))  # -dlog2(p(y_1:T))
            Alphas[0] = -phi / (1 - phi**2) + phi * (X / sigmax)**2
            Alphas[1] = -1 / sigmax + (1 - phi**2) * X**2 / sigmax**3
            Alphas[2]=(y[0])**2*np.exp(-X)/sigmay**3-1/sigmay
            #print(X.shape)
            Betas[:, 0, 0] = (X / sigmax)**2 - 1 / (1 - phi**2) - 2 * phi**2 / (1 - phi**2)**2
            Betas[:, 0, 1] = -2 * phi * X**2 / sigmax**3
            Betas[:, 1, 0] = Betas[:, 0, 1]
            Betas[:, 1, 1] = 1 / (sigmax**2) - 3 * X**2 * (1 - phi**2) / (sigmax**4)
            Betas[:, 2, 2] =-3*(y[0])**2*np.exp(-X)/sigmay**4 +1/sigmay**2
            Sn[0, :] = np.mean(Alphas, axis=1)
            Sigma[0, :, :] = -np.cov(Alphas,bias=True) - np.mean(Betas, axis=0)
            for t in np.arange(1,T):
                X_tem=np.random.normal(phi*X,sigmax,N) 
                log_w=-X_tem/2-(y[t])**2*np.exp(-X_tem)/2/sigmay**2
                #X=np.append(X,[X_tem],axis=0)
                ind=SV.resample(log_w)
                X=X[ind]
                X_tem=X_tem[ind]
                Alphas=Alphas[:,ind]
                Betas=Betas[ind,:,:]
                Alphas[0]+=X*(X_tem-phi*X)/sigmax**2
                Alphas[1]+=(X_tem-phi*X)**2/sigmax**3-1/sigmax
                Alphas[2]+=(y[t])**2*np.exp(-X_tem)/sigmay**3   -1/sigmay
                Betas[:,0,0]+=-X**2/sigmax**2
                Betas[:,0,1]+=-2*X*(X_tem-phi*X)/sigmax**3
                Betas[:,1,0]=Betas[:,0,1]
                #Betas[:,0,2]+=-X**2/sigmax**2
                #Betas[:,2,0]+=-X**2/sigmax**2
                Betas[:,1,1]+=-3*(X_tem-phi*X)**2/sigmax**4+1/sigmax**2
               # Betas[:,1,2]+=-X**2/sigmax**2
                #Betas[:,2,1]+=-X**2/sigmax**2
                Betas[:,2,2]+=-3*(y[t])**2*np.exp(-X_tem)/sigmay**4+1/sigmay**2
                Sn[t, :] = np.mean(Alphas, axis=1)
                Sigma[t, :, :] = -np.cov(Alphas,bias=True) - np.mean(Betas, axis=0)
                X=X_tem


                #test=Sn[t, :].reshape(3,1).dot([Sn[t, :]])-Alphas.dot(Alphas.T)/N - np.mean(Betas, axis=0)
                #print(test-Sigma[t])
            #grad_phi=np.sum(X[:-1]*(X[1:]-phi*X[:-1]))/sigmax**2/N -phi / (1 - phi**2) + phi * np.mean(X**2) / sigmax**2
            #grad_sx=np.sum((X[1:]-phi*X[:-1])**2)/sigmax**3/N-T/sigmax +(1-phi**2)*np.mean(X**2)/sigmax**3
            #grad_sy=np.sum((y[:,None]-X)**2)/sigmay**3/N-(T)/sigmay
            
            #grad=np.array([grad_phi,grad_sx,grad_sy])
            #print(Sn[-1]-grad,'diff')
            
            #log_w=np.zeros(N)
            #grad_phi=np.sum(X[:-1]*(X[1:]-phi*X[:-1]))/sigmax**2/N -phi / (1 - phi**2) + phi * np.mean(X**2) / sigmax**2
            #grad_sx=np.sum((X[1:]-phi*X[:-1])**2)/sigmax**3/N-T/sigmax -1/sigmax+(1-phi**2)*np.mean(X**2)/sigmax**3
            #grad_sy=np.sum((y[:,None]-X)**2)/sigmay**3/N-(T+1)/sigmay
            
            #grad=np.array([grad_phi,grad_sx,grad_sy])
            #print(grad)
            #an=c1/((nI+A)**alpha)
            #thetalist=np.append(thetalist,[thetalist[-1]+an*Sn[-1] ],axis=0)
            
            #test_S[0,0]=
            #print(np.mean(Betas, axis=0))
            #print(Sigma[-1])
            #print(np.linalg.inv(Sigma[-1]))
            thetalist=np.append(thetalist,[thetalist[-1]+(nI+2)**(-2/3)*np.linalg.inv(Sigma[-1]).dot(Sn[-1]) ],axis=0)
            #print(thetalist[-1],nI)
        self.thetalist = thetalist

    

        #with r2 resampling control,bt proposal    

    
          
    def ON2(self,ini,I,N):   
        thetalist=np.array([ini])#[]?
        y=self.y
        T=self.T
        for nI in range(I):
            phi,sigma,tau=thetalist[-1]
            sigma0=(1-phi**2)**-0.5*sigma
            X = np.random.normal(0, sigma0, N)  # Initialise
            log_w=-X/2-(y[0])**2*np.exp(-X)/2/sigma**2
            ind=SV.resample(log_w)
            X=X[ind]
            
            Alphas = np.zeros((3, N))  # dlogP(x_n,y_1:n)
            Sn = np.zeros((T, 3))  # dlogP(y_1:n)
            Betas = np.zeros((N, 3, 3))  # dlog2(p(x_1:T,y_1:T))
            Sigma = np.zeros((T, 3, 3))  # -dlog2(p(y_1:T))
            Alphas[0, :] = -phi / (1 - phi**2) + phi * (X / sigma)**2
            Alphas[1, :] = -1 / sigma + (1 - phi**2) * X**2 / sigma**3
            Alphas[2, :] = -1 / tau + y[0]**2*np.exp(-X) / tau**3  #
            
            Betas[:, 0, 0] = (X / sigma)**2 - 1 / (1 - phi**2) - 2 * phi**2 / (1 - phi**2)**2
            Betas[:, 0, 1] = -2 * phi * X**2 / sigma**3
            Betas[:, 1, 0] = Betas[:, 0, 1]
            Betas[:, 1, 1] = 1 / (sigma**2) - 3 * X**2 * (1 - phi**2) / (sigma**4)
            Betas[:, 2, 2] = 1 / (tau**2) - 3 * y[0]**2*np.exp(-X) / (tau**4)##
            Sn[0, :] = np.mean(Alphas, axis=1)
            Sigma[0, :, :] = -np.cov(Alphas,bias=True) - np.mean(Betas, axis=0)

            for t in range(1, T):

                X_tem=np.random.normal(phi*X,sigma,N) 
                log_w=-X_tem/2-(y[t])**2*np.exp(-X_tem)/2/sigma**2
                #X=np.append(X,[X_tem],axis=0)
                ind=SV.resample(log_w)
                X=X[ind]
                X_tem=X_tem[ind]
                Alphas=Alphas[:,ind]
                Betas=Betas[ind,:,:]
                X1=X
                X=X_tem

                # Calculate w[t]f_theta(X[t]|X[t-1])
                xtemp = np.tile(X, (N, 1)).T
                x1temp = np.tile(phi * X1, (N, 1))#.T
                #print(xtemp,x1temp)
                wf = xtemp - x1temp
                wf = np.exp(-0.5 * wf**2 /sigma**2) / np.sqrt(2 * np.pi * sigma**2) #?
                sum_f = np.sum(wf, axis=1)

                # Estimate the joint score 
                Alphas_n = Alphas.copy()  # concern over updating alpha whilst running the recursions
                Alphas_n[0, :] = [np.sum(wf[i, :] * (Alphas[0, :] + (X1 / sigma**2) * (X[i] - phi * X1)))/sum_f[i] for i in range(N)]
                Alphas_n[1, :] = [np.sum(wf[i, :] * (Alphas[1, :] - 1/sigma + (X[i] - phi * X1)**2 / sigma**3))/sum_f[i] for i in range(N)]
                Alphas_n[2, :] = [np.sum(wf[i, :] * (Alphas[2, :] - 1/tau + (1/tau**3) * (y[t])**2*np.exp(-X[i])))/sum_f[i] for i in range(N)]

                # Estimate observed information of joint dist
                Betas_n = Betas.copy()
                Betas_n[:, 0, 0] = [np.sum(wf[i, :] / sum_f[i] * ((Alphas[0, :] + (X1 / sigma**2) * (X[i] - phi * X1))**2 + (Betas[:, 0, 0] - (X1 / sigma)**2))) - Alphas_n[0, i] * Alphas_n[0, i].T for i in range(N)]
                Betas_n[:, 0, 1] = [np.sum(wf[i, :] / sum_f[i] * ((Betas[:, 0, 1] - (2 * X1 / (sigma**3)) * (X[i] - phi * X1)) + (Alphas[0, :] + (X1 / sigma**2) * (X[i] - phi * X1)) * (Alphas[1, :] - 1/sigma + (X[i] - phi * X1)**2 / sigma**3))) - Alphas_n[0, i] * Alphas_n[1, i].T for i in range(N)]
                Betas_n[:, 1, 0] = Betas_n[:, 0, 1]
                Betas_n[:, 0, 2] = [np.sum(wf[i, :] / sum_f[i] * ((Alphas[0, :] + (X1 / sigma**2) * (X[i] - phi * X1)) * (Alphas[2, :] - 1/tau + (1/tau**3) * (y[t])**2*np.exp(-X[i]) ))) - Alphas_n[0, i] * Alphas_n[2, i].T for i in range(N)]
                Betas_n[:, 2, 0] = Betas_n[:, 0, 2]
                Betas_n[:, 1, 1] = [np.sum(wf[i, :] / sum_f[i] * ((Betas[:, 1, 1] + 1/sigma**2 - 3 * (X[i] - phi * X1)**2 / (sigma**4)) + (Alphas[1, :] - 1/sigma + (X[i] - phi * X1)**2 / sigma**3)**2)) - Alphas_n[1, i] * Alphas_n[1, i].T for i in range(N)]
                Betas_n[:, 1, 2] = [np.sum(wf[i, :] / sum_f[i] * ((Alphas[1, :] - 1/sigma + (X[i] - phi * X1)**2 / sigma**3) * (Alphas[2, :] - 1/tau + (1/tau**3) * (y[t])**2*np.exp(-X[i])   ))) - Alphas_n[1, i] * Alphas_n[2, i].T for i in range(N)]
                Betas_n[:, 2, 1] = Betas_n[:, 1, 2]
                Betas_n[:, 2, 2] = [np.sum(wf[i, :] / sum_f[i] * ((Betas[:, 2, 2] + 1/tau**2 - 3 *(y[t])**2*np.exp(-X[i]) / (tau**4)) + (Alphas[2, :] - 1/tau + (1/tau**3) *(y[t])**2*np.exp(-X[i]))**2)) - Alphas_n[2, i] * Alphas_n[2, i].T for i in range(N)]

                Alphas = Alphas_n
                Betas = Betas_n
                # Score estimate
                Sn[t, :] = np.mean(Alphas, axis=1)

                ########################
                # Hessian
                Sigma[t, :, :] = -np.cov(Alphas,bias=True) - np.mean(Betas, axis=0)
                
            #an=c1/((nI+A)**alpha)  
            thetalist=np.append(thetalist,[thetalist[-1]+(nI+10)**(-2/3)*np.linalg.inv(Sigma[-1,:,:]).dot(Sn[-1]) ],axis=0)
            #thetalist=np.append(thetalist,[thetalist[-1]+an*Sn[-1] ],axis=0)
            #print(thetalist[-1])
        self.thetalist = thetalist
        
    def onGA1(self,ini,c1,A,alpha,N,r1,r2,REP):
        thetalist=np.array([ini])
        y=self.y
        T=self.T
        
        k1=0
        renew_t=[]
        #phi_l,sigmax_l,sigmay_l=ini
        for rep in range(REP):
            phi_l,sigmax_l,sigmay_l=thetalist[-1]
            phi,sigmax,sigmay=thetalist[-1]
            sigma0=(1-phi**2)**-0.5*sigmax
            X=np.random.normal(0,sigma0,N)  #q(x0|y0=mu(x0))
            log_w=-X/2-(y[0])**2*np.exp(-X)/2/sigmay**2
            ind=SV.resample(log_w)
            X=X[ind]
            X0=X
            X1_sq=np.zeros(N)
            X1__1=np.zeros(N)
            X_1sq=np.zeros(N)
            y_x=(y[0])**2*np.exp(-X)
            log_w=np.zeros(N)
            for t in np.arange(1,T):
            
                #propagation
                an=T*c1/(t+A+rep*T)**alpha#a_t=(T+1)*c1/((rep*T+t+A)**alpha)
                phi,sigmax,sigmay=thetalist[-1]

                X_tem=np.random.normal(phi*X,sigmax,N)

                #oldgrad
                #print(t,thetalist[-1][0])
                #print(X[:-1])
                vec2_phi=X1__1-phi*X_1sq  + phi *(X0**2) 
                grad2_phi=SV.fisher(vec2_phi,log_w)/sigmax**2
                vec2_s=X1_sq-2*phi*X1__1+phi**2*X_1sq
                vec2_sx=vec2_s+(1-phi**2)*(X0**2)
                grad2_sx=SV.fisher(vec2_sx,log_w)/sigmax**3
                vec2_sy=y_x
                grad2_sy=SV.fisher(vec2_sy,log_w)/sigmay**3

                log_w+=-X_tem/2-(y[t])**2*np.exp(-X_tem)/2/sigmay**2
                X1_sq+=X_tem**2
                X1__1+=X*X_tem
                X_1sq+=X**2
                y_x+=(y[t])**2*np.exp(-X_tem)
                
                vec1_phi=vec2_phi+X*(X_tem-phi*X) 
                vec1_sx=vec2_sx+(X_tem-phi*X)**2
                vec1_sy=y_x



                grad1_phi=SV.fisher(vec1_phi,log_w)/sigmax**2
                grad1_sx=SV.fisher(vec1_sx,log_w)/sigmax**3
                grad1_sy=SV.fisher(vec1_sy,log_w)/sigmay**3

                grad_phi=grad1_phi-grad2_phi
                grad_sx=grad1_sx-grad2_sx-1/sigmax
                grad_sy=grad1_sy-grad2_sy-1/sigmay
                #grad_sx,grad_sy=0,0
                grad=np.array([grad_phi,grad_sx,grad_sy])

                thetalist=np.append(thetalist,[thetalist[-1]+an*grad],axis=0)

                #
                vec3=y_x
                islogw=SV.getisw(X0**2,X1_sq,X1__1,X_1sq,phi,sigmax,sigmay,phi_l,sigmax_l,sigmay_l,vec3)
                rtgt_logw=SV.getisw(X0**2,X1_sq,X1__1,X_1sq,phi,sigmax,sigmay,thetalist[-2][0],thetalist[-2][1],thetalist[-2][2],vec3)
                        
                log_w+=rtgt_logw


                ess_a=SV.ess(islogw)/N
                ess_w=SV.ess(log_w)/N
                
                X=X_tem
                #print(thetalist[-1])


                #print(ess_a,ess_w)          
                if(ess_a<r1):
                    k1+=1
                    renew_t.append([t+rep*T])
                    phi_l,sigmax_l,sigmay_l=thetalist[-1]
                    sigma0_l=(1-phi_l**2)**-0.5*sigmax_l
                    X=np.random.normal(0,sigma0_l,N)   #q(x0|y0=mu(x0))
                    log_w=-X/2-(y[0])**2*np.exp(-X)/2/sigmay_l**2
                    ind=SV.resample(log_w)
                    X=X[ind]
                    X0=X
                    X1_sq=np.zeros(N)
                    X1__1=np.zeros(N)
                    X_1sq=np.zeros(N)
                    y_x=(y[0])**2*np.exp(-X)
                    for t1 in np.arange(1,t+1):
                        X_tem=np.random.normal(phi_l*X,sigmax_l,N)#bootstrap,q(xt|xt-1,yt)=f(xt|xt-1))
                        log_w=-X_tem/2-(y[t1])**2*np.exp(-X_tem)/2/sigmay_l**2
                        X1_sq+=X_tem**2
                        X1__1+=X*X_tem
                        X_1sq+=X**2
                        y_x+=(y[t1])**2*np.exp(-X_tem)
                        ind=SV.resample(log_w)
                        X=X_tem[ind]
                        X1_sq=X1_sq[ind]
                        X1__1=X1__1[ind]
                        X_1sq=X_1sq[ind]
                        y_x=y_x[ind]
                        X0=X0[ind]
                    log_w=np.zeros(N)

                elif(ess_w<r2):
                    ind=SV.resample(log_w)
                    X=X[ind]
                    X1_sq=X1_sq[ind]
                    X1__1=X1__1[ind]
                    X_1sq=X_1sq[ind]
                    y_x=y_x[ind]
                    X0=X0[ind]
                    log_w=np.zeros(N)
        #print(k1)
        self.renew_t=renew_t
        self.k1=k1
        self.thetalist = thetalist 
        
    #code for likelihood-surface illustration    
    def onGA_2p(self,ini,c1,A,alpha,N,r1,r2,REP):
        thetalist=np.array([ini])
        y=self.y
        T=self.T
        
        k1=0
        renew_t=[]
        #phi_l,sigmax_l,sigmay_l=ini
        for rep in range(REP):
            phi_l,sigmax_l,sigmay_l=thetalist[-1]
            phi,sigmax,sigmay=thetalist[-1]
            sigma0=(1-phi**2)**-0.5*sigmax
            X=np.random.normal(0,sigma0,N)  #q(x0|y0=mu(x0))
            log_w=-X/2-(y[0])**2*np.exp(-X)/2/sigmay**2
            ind=SV.resample(log_w)
            X=X[ind]
            X0=X
            X1_sq=np.zeros(N)
            X1__1=np.zeros(N)
            X_1sq=np.zeros(N)
            y_x=(y[0])**2*np.exp(-X)
            log_w=np.zeros(N)
            for t in np.arange(1,T):
            
                #propagation
                an=T*c1/(t+A+rep*T)**alpha#a_t=(T+1)*c1/((rep*T+t+A)**alpha)
                phi,sigmax,sigmay=thetalist[-1]

                X_tem=np.random.normal(phi*X,sigmax,N)

                #oldgrad
                #print(t,thetalist[-1][0])
                #print(X[:-1])
                vec2_phi=X1__1-phi*X_1sq  + phi *(X0**2) 
                grad2_phi=SV.fisher(vec2_phi,log_w)/sigmax**2
                vec2_s=X1_sq-2*phi*X1__1+phi**2*X_1sq
                vec2_sx=vec2_s+(1-phi**2)*(X0**2)
                grad2_sx=SV.fisher(vec2_sx,log_w)/sigmax**3
                vec2_sy=y_x
                grad2_sy=SV.fisher(vec2_sy,log_w)/sigmay**3

                log_w+=-X_tem/2-(y[t])**2*np.exp(-X_tem)/2/sigmay**2
                X1_sq+=X_tem**2
                X1__1+=X*X_tem
                X_1sq+=X**2
                y_x+=(y[t])**2*np.exp(-X_tem)
                
                vec1_phi=vec2_phi+X*(X_tem-phi*X) 
                vec1_sx=vec2_sx+(X_tem-phi*X)**2
                vec1_sy=y_x



                grad1_phi=SV.fisher(vec1_phi,log_w)/sigmax**2
                grad1_sx=SV.fisher(vec1_sx,log_w)/sigmax**3
                grad1_sy=SV.fisher(vec1_sy,log_w)/sigmay**3

                grad_phi=grad1_phi-grad2_phi
                grad_sx=grad1_sx-grad2_sx-1/sigmax
                grad_sy=grad1_sy-grad2_sy-1/sigmay
                grad_sx=0
                grad=np.array([grad_phi,grad_sx,grad_sy])

                thetalist=np.append(thetalist,[thetalist[-1]+an*grad],axis=0)

                #
                vec3=y_x
                islogw=SV.getisw(X0**2,X1_sq,X1__1,X_1sq,phi,sigmax,sigmay,phi_l,sigmax_l,sigmay_l,vec3)
                rtgt_logw=SV.getisw(X0**2,X1_sq,X1__1,X_1sq,phi,sigmax,sigmay,thetalist[-2][0],thetalist[-2][1],thetalist[-2][2],vec3)
                        
                log_w+=rtgt_logw


                ess_a=SV.ess(islogw)/N
                ess_w=SV.ess(log_w)/N
                
                X=X_tem
                #print(thetalist[-1])


                #print(ess_a,ess_w)          
                if(ess_a<r1):
                    k1+=1
                    renew_t.append([t+rep*T])
                    phi_l,sigmax_l,sigmay_l=thetalist[-1]
                    sigma0_l=(1-phi_l**2)**-0.5*sigmax_l
                    X=np.random.normal(0,sigma0_l,N)   #q(x0|y0=mu(x0))
                    log_w=-X/2-(y[0])**2*np.exp(-X)/2/sigmay_l**2
                    ind=SV.resample(log_w)
                    X=X[ind]
                    X0=X
                    X1_sq=np.zeros(N)
                    X1__1=np.zeros(N)
                    X_1sq=np.zeros(N)
                    y_x=(y[0])**2*np.exp(-X)
                    for t1 in np.arange(1,t+1):
                        X_tem=np.random.normal(phi_l*X,sigmax_l,N)#bootstrap,q(xt|xt-1,yt)=f(xt|xt-1))
                        log_w=-X_tem/2-(y[t1])**2*np.exp(-X_tem)/2/sigmay_l**2
                        X1_sq+=X_tem**2
                        X1__1+=X*X_tem
                        X_1sq+=X**2
                        y_x+=(y[t1])**2*np.exp(-X_tem)
                        ind=SV.resample(log_w)
                        X=X_tem[ind]
                        X1_sq=X1_sq[ind]
                        X1__1=X1__1[ind]
                        X_1sq=X_1sq[ind]
                        y_x=y_x[ind]
                        X0=X0[ind]
                    log_w=np.zeros(N)

                elif(ess_w<r2):
                    ind=SV.resample(log_w)
                    X=X[ind]
                    X1_sq=X1_sq[ind]
                    X1__1=X1__1[ind]
                    X_1sq=X_1sq[ind]
                    y_x=y_x[ind]
                    X0=X0[ind]
                    log_w=np.zeros(N)
        #print(k1)
        self.renew_t=renew_t
        self.k1=k1
        self.thetalist = thetalist 
        
        
    def AGA_2p(self,ini,c1,A,alpha,I,N,r,inner_K):   
        thetalist=np.array([ini])
        y=self.y
        T=self.T
        n=0
        newt=[0]
        for nI in range(I):
            k=0
            ess=2
            
            phi_l,sigmax_l,sigmay_l=thetalist[-1]
            sigma0_l=(1-phi_l**2)**-0.5*sigmax_l
            X=np.random.normal(0,sigma0_l,N)  #q(x0|y0=mu(x0))
            log_w=-X/2-(y[0])**2*np.exp(-X)/2/sigmay_l**2
            ind=SV.resample(log_w)
            X=X[ind]
            X0=X
            X1_sq=np.zeros(N)
            X1__1=np.zeros(N)
            X_1sq=np.zeros(N)
            y_x=(y[0])**2*np.exp(-X)
            
            
            
            for t in np.arange(1,T):             
                X_tem=np.random.normal(phi_l*X,sigmax_l,N) 
                log_w=-X_tem/2-(y[t])**2*np.exp(-X_tem)/2/sigmay_l**2
                #X=np.append(X,[X_tem],axis=0)
                
                X1_sq+=X_tem**2
                X1__1+=X*X_tem
                X_1sq+=X**2
                y_x+=(y[t])**2*np.exp(-X_tem)
                
                
                ind=SV.resample(log_w)
                X=X_tem[ind]
                X1_sq=X1_sq[ind]
                X1__1=X1__1[ind]
                X_1sq=X_1sq[ind]
                y_x=y_x[ind]
                X0=X0[ind]
                
            islogw=np.zeros(N)
            while ((ess > r)&(k<inner_K)):
                n+=1
                k+=1
                an=c1/((n+A)**alpha)
                phi,sigmax,sigmay=thetalist[-1]
                
                
                
                #vec1=np.sum(X[:-1]*(X[1:]-phi*X[:-1]),axis=0)                
                #vec1=np.sum(X[:-1]*(X[1:]-phi*X[:-1]),axis=0)  + phi *(X[0]**2) / sigmax**2
            
                vec1=X1__1-phi*X_1sq  + phi *(X0**2) 
                grad_phi=SV.fisher(vec1,islogw)/sigmax**2-phi / (1 - phi**2)
                
                #vec2=np.sum((X[1:]-phi*X[:-1])**2,axis=0) 
                #vec2=np.sum((X[1:]-phi*X[:-1])**2,axis=0) -1/sigmax+(1-phi**2)*(X[0]**2)/sigmax**3
                vec2_s=X1_sq-2*phi*X1__1+phi**2*X_1sq
                vec2=vec2_s/sigmax**3 -1/sigmax+(1-phi**2)*(X0**2)/sigmax**3
                grad_sx=SV.fisher(vec2,islogw)-(T-1)/sigmax
                grad_sx=0
                
                vec3=y_x
                grad_sy=SV.fisher(vec3,islogw)/sigmay**3-T/sigmay
                grad=np.array([grad_phi,grad_sx,grad_sy])
                
                thetalist=np.append(thetalist,[thetalist[-1]+an*grad],axis=0)
                
                
                #islogwx=-np.sum((X[1:]-phi*X[:-1])**2,axis=0)/2/sigmax**2+np.sum((X[1:]-phi_l*X[:-1])**2,axis=0)/2/sigmax_l**2      
                #islogwy=(-1/2/sigmay**2+1/2/sigmay_l**2)*vec3
                #islogw=islogwx+islogwy
                islogw=SV.getisw(X0**2,X1_sq,X1__1,X_1sq,phi,sigmax,sigmay,phi_l,sigmax_l,sigmay_l,vec3)
                ess=SV.ess(islogw)/N
            newt.append(newt[-1]+k)
            #print(k)
        self.newt=newt    
        self.thetalist = thetalist